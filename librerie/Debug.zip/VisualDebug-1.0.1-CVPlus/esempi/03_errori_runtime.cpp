#include <iostream>
#include <stdexcept>
#include <visual_debug.h>
using namespace std;

int main() {
    VDBG_START("Controllo errori");

    VDBG_RUN(
        int divisore = 0;
        VDBG_VAR(divisore);
        VDBG_ASSERT(divisore != 0);

        if (divisore == 0) {
            throw runtime_error("Divisione per zero evitata");
        }

        cout << 100 / divisore << endl;
    );
}
