#include <iostream>
#include <visual_debug.h>
using namespace std;

int main() {
    VDBG_START("Debug di un ciclo");

    int somma = 0;
    for (int i = 1; i <= 5; i++) {
        somma += i;

        VDBG_VAR(i);
        VDBG_VAR(somma);
        VDBG_BREAKPOINT("Fine iterazione");
    }

    VDBG_FINISH();
    return 0;
}
