#include <iostream>
#include <visual_debug.h>
using namespace std;

int main() {
    VDBG_START("Esempio variabili");

    int eta = 16;
    double media = 7.75;
    string nome = "Luca";

    VDBG_VAR(nome);
    VDBG_VAR(eta);
    VDBG_VAR(media);

    eta++;
    media = (media + 8.5) / 2.0;

    VDBG_MSG("Valori dopo il calcolo");
    VDBG_VAR(eta);
    VDBG_VAR(media);

    VDBG_FINISH();
    return 0;
}
