#include <iostream>
using namespace std;

int main() {
    int numero;

    while (1) {
        cout << "Inserisci un numero (0 per terminare): ";
        cin >> numero;

        if (numero == 0) {
            cout << "Programma terminato." << endl;
            break;
        }

        cout << "Il doppio e': " << numero * 2 << endl;
    }

    return 0;
}
