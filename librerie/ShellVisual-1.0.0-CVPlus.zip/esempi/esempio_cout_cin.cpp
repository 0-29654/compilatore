#include <iostream>
#include <string>
using namespace std;

int main() {
    string nome;
    int eta;

    cout << "Come ti chiami? ";
    cin >> nome;
    cout << "Quanti anni hai? ";
    cin >> eta;

    cout << "Ciao " << nome << ", hai " << eta << " anni." << endl;
    cout << "Puoi chiudere la finestra con il pulsante ESCI." << endl;
    return 0;
}
