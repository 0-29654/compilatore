#ifndef ARRAY_VISUAL_H
#define ARRAY_VISUAL_H

#ifdef _WIN32
  #ifdef ARRAY_VISUAL_EXPORTS
    #define ARRAY_VISUAL_API __declspec(dllexport)
  #else
    #define ARRAY_VISUAL_API __declspec(dllimport)
  #endif
#else
  #define ARRAY_VISUAL_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

// algoritmo: 1 = Bubble Sort, 2 = Selection Sort, 3 = Insertion Sort.
// Alla chiusura della finestra, l'array contiene i valori ordinati.
ARRAY_VISUAL_API void visualizzaOrdinamento(int valori[], int dimensione, int algoritmo = 1);
ARRAY_VISUAL_API void visualizzaOrdinamentoChar(char valori[], int dimensione, int algoritmo = 1);

#ifdef __cplusplus
}
#endif

#endif
