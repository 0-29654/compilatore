#define ARRAY_VISUAL_EXPORTS
#include "../array_visual.h"

// Implementazione WinAPI senza dipendenze dal runtime C++.
extern "C" void* memset(void* d, int c, unsigned long long n){ unsigned char* p=(unsigned char*)d; for(unsigned long long i=0;i<n;i++) p[i]=(unsigned char)c; return d; }
extern "C" void* memcpy(void* d, const void* s, unsigned long long n){ unsigned char* a=(unsigned char*)d; const unsigned char* b=(const unsigned char*)s; for(unsigned long long i=0;i<n;i++) a[i]=b[i]; return d; }

typedef void* HANDLE; typedef HANDLE HINSTANCE; typedef HANDLE HWND; typedef HANDLE HBRUSH; typedef HANDLE HDC; typedef HANDLE HFONT; typedef HANDLE HGDIOBJ; typedef HANDLE HMENU;
typedef unsigned long DWORD; typedef unsigned int UINT; typedef unsigned long long UINT_PTR; typedef long long LPARAM; typedef unsigned long long WPARAM; typedef long long LRESULT; typedef int BOOL; typedef unsigned short WORD; typedef const wchar_t* LPCWSTR; typedef wchar_t WCHAR; typedef unsigned char BYTE; typedef unsigned long ULONG_PTR; typedef ULONG_PTR SIZE_T; typedef unsigned short ATOM;
struct POINT { long x,y; }; struct MSG { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; DWORD lPrivate; };
struct RECT { long left,top,right,bottom; };
struct PAINTSTRUCT { HDC hdc; BOOL fErase; RECT rcPaint; BOOL fRestore; BOOL fIncUpdate; BYTE rgbReserved[32]; };
struct WNDCLASSEXW { UINT cbSize; UINT style; LRESULT (__stdcall *lpfnWndProc)(HWND,UINT,WPARAM,LPARAM); int cbClsExtra; int cbWndExtra; HINSTANCE hInstance; HANDLE hIcon; HANDLE hCursor; HBRUSH hbrBackground; LPCWSTR lpszMenuName; LPCWSTR lpszClassName; HANDLE hIconSm; };

extern "C" {
__declspec(dllimport) HINSTANCE __stdcall GetModuleHandleW(LPCWSTR);
__declspec(dllimport) HANDLE __stdcall GetProcessHeap();
__declspec(dllimport) void* __stdcall HeapAlloc(HANDLE,DWORD,SIZE_T);
__declspec(dllimport) BOOL __stdcall HeapFree(HANDLE,DWORD,void*);
__declspec(dllimport) void __stdcall ExitProcess(UINT);
__declspec(dllimport) ATOM __stdcall RegisterClassExW(const WNDCLASSEXW*);
__declspec(dllimport) HWND __stdcall CreateWindowExW(DWORD,LPCWSTR,LPCWSTR,DWORD,int,int,int,int,HWND,HMENU,HINSTANCE,void*);
__declspec(dllimport) BOOL __stdcall ShowWindow(HWND,int);
__declspec(dllimport) BOOL __stdcall UpdateWindow(HWND);
__declspec(dllimport) BOOL __stdcall GetMessageW(MSG*,HWND,UINT,UINT);
__declspec(dllimport) BOOL __stdcall TranslateMessage(const MSG*);
__declspec(dllimport) LRESULT __stdcall DispatchMessageW(const MSG*);
__declspec(dllimport) LRESULT __stdcall DefWindowProcW(HWND,UINT,WPARAM,LPARAM);
__declspec(dllimport) void __stdcall PostQuitMessage(int);
__declspec(dllimport) BOOL __stdcall DestroyWindow(HWND);
__declspec(dllimport) BOOL __stdcall InvalidateRect(HWND,const RECT*,BOOL);
__declspec(dllimport) UINT_PTR __stdcall SetTimer(HWND,UINT_PTR,UINT,void*);
__declspec(dllimport) BOOL __stdcall KillTimer(HWND,UINT_PTR);
__declspec(dllimport) HDC __stdcall BeginPaint(HWND,PAINTSTRUCT*);
__declspec(dllimport) BOOL __stdcall EndPaint(HWND,const PAINTSTRUCT*);
__declspec(dllimport) BOOL __stdcall GetClientRect(HWND,RECT*);
__declspec(dllimport) int __stdcall DrawTextW(HDC,LPCWSTR,int,RECT*,UINT);
__declspec(dllimport) BOOL __stdcall TextOutW(HDC,int,int,LPCWSTR,int);
__declspec(dllimport) unsigned long __stdcall SetTextColor(HDC,unsigned long);
__declspec(dllimport) HBRUSH __stdcall CreateSolidBrush(unsigned long);
__declspec(dllimport) int __stdcall FillRect(HDC,const RECT*,HBRUSH);
__declspec(dllimport) BOOL __stdcall DeleteObject(HGDIOBJ);
__declspec(dllimport) HGDIOBJ __stdcall SelectObject(HDC,HGDIOBJ);
__declspec(dllimport) HFONT __stdcall CreateFontW(int,int,int,int,int,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,LPCWSTR);
__declspec(dllimport) HANDLE __stdcall LoadCursorW(HINSTANCE,LPCWSTR);
}

#define WINAPI __stdcall
#define WM_DESTROY 0x0002
#define WM_PAINT 0x000F
#define WM_COMMAND 0x0111
#define WM_TIMER 0x0113
#define WS_OVERLAPPEDWINDOW 0x00CF0000L
#define WS_VISIBLE 0x10000000L
#define WS_CHILD 0x40000000L
#define BS_PUSHBUTTON 0
#define CW_USEDEFAULT 0x80000000
#define SW_SHOW 5
#define COLOR_WINDOW 5
#define IDC_ARROW ((LPCWSTR)32512)
#define DT_CENTER 0x00000001
#define DT_VCENTER 0x00000004
#define DT_SINGLELINE 0x00000020
#define TRANSPARENT 1
#define FW_BOLD 700
#define DEFAULT_CHARSET 1
#define OUT_DEFAULT_PRECIS 0
#define CLIP_DEFAULT_PRECIS 0
#define DEFAULT_QUALITY 0
#define DEFAULT_PITCH 0
#define FF_DONTCARE 0
#define TRUE 1
#define FALSE 0

static unsigned long RGBc(unsigned r,unsigned g,unsigned b){return r|(g<<8)|(b<<16);} 
static int loword(WPARAM v){return (int)(v & 0xffff);}
static int wlen(const wchar_t* s){int n=0; while(s&&s[n]) n++; return n;}
static void intToW(int value,wchar_t* out){ wchar_t tmp[24]; int n=0; bool neg=value<0; unsigned int v=neg?(unsigned int)(-value):(unsigned int)value; do{tmp[n++]=(wchar_t)(L'0'+v%10);v/=10;}while(v); int p=0;if(neg)out[p++]=L'-';while(n)out[p++]=tmp[--n];out[p]=0; }

struct Step { int* data; int a,b; int swapped; };
static Step* g_steps=0; static int g_stepCount=0,g_current=0,g_n=0; static int* g_original=0; static HWND g_hwnd=0; static bool g_auto=false; static bool g_charMode=false; static int g_algorithm=1;

static void cleanup(){ HANDLE hp=GetProcessHeap(); if(g_steps){for(int i=0;i<g_stepCount;i++) if(g_steps[i].data) HeapFree(hp,0,g_steps[i].data); HeapFree(hp,0,g_steps);} g_steps=0; if(g_original)HeapFree(hp,0,g_original);g_original=0;g_stepCount=g_current=g_n=0; }
static int* cloneData(const int* a,int n){int* p=(int*)HeapAlloc(GetProcessHeap(),0,(SIZE_T)n*sizeof(int));if(!p)return 0;for(int i=0;i<n;i++)p[i]=a[i];return p;}
static void addStep(const int* a,int n,int x,int y,int sw){Step* ns=(Step*)HeapAlloc(GetProcessHeap(),0,(SIZE_T)(g_stepCount+1)*sizeof(Step));if(!ns)return;for(int i=0;i<g_stepCount;i++)ns[i]=g_steps[i];ns[g_stepCount].data=cloneData(a,n);ns[g_stepCount].a=x;ns[g_stepCount].b=y;ns[g_stepCount].swapped=sw;if(g_steps)HeapFree(GetProcessHeap(),0,g_steps);g_steps=ns;g_stepCount++;}
static void buildBubble(const int* input,int n){
 g_original=cloneData(input,n);int* a=cloneData(input,n);addStep(a,n,-1,-1,0);
 for(int pass=0;pass<n-1;pass++){bool changed=false;for(int j=0;j<n-1-pass;j++){addStep(a,n,j,j+1,0);if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;changed=true;addStep(a,n,j,j+1,1);}}if(!changed)break;}
 addStep(a,n,-1,-1,0);HeapFree(GetProcessHeap(),0,a);
}
static void buildSelection(const int* input,int n){
 g_original=cloneData(input,n);int* a=cloneData(input,n);addStep(a,n,-1,-1,0);
 for(int i=0;i<n-1;i++){int min=i;for(int j=i+1;j<n;j++){addStep(a,n,min,j,0);if(a[j]<a[min])min=j;}if(min!=i){int t=a[i];a[i]=a[min];a[min]=t;addStep(a,n,i,min,1);}else addStep(a,n,i,i,0);}
 addStep(a,n,-1,-1,0);HeapFree(GetProcessHeap(),0,a);
}
static void buildInsertion(const int* input,int n){
 g_original=cloneData(input,n);int* a=cloneData(input,n);addStep(a,n,-1,-1,0);
 for(int i=1;i<n;i++){int key=a[i];int j=i-1;addStep(a,n,j,i,0);while(j>=0&&a[j]>key){a[j+1]=a[j];addStep(a,n,j,j+1,1);j--;if(j>=0)addStep(a,n,j,j+1,0);}a[j+1]=key;addStep(a,n,j+1,i,1);}
 addStep(a,n,-1,-1,0);HeapFree(GetProcessHeap(),0,a);
}
static void buildSteps(const int* input,int n,int algorithm){if(algorithm==2)buildSelection(input,n);else if(algorithm==3)buildInsertion(input,n);else buildBubble(input,n);}

static void makeButton(HWND parent,const wchar_t* text,int id,int x,int y,int w){CreateWindowExW(0,L"BUTTON",text,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,x,y,w,34,parent,(HMENU)(UINT_PTR)id,GetModuleHandleW(0),0);} 

static LRESULT WINAPI wndproc(HWND h,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_COMMAND){int id=loword(wp);if(id==101&&g_current>0)g_current--;else if(id==102&&g_current<g_stepCount-1)g_current++;else if(id==103){g_auto=true;SetTimer(h,1,650,0);}else if(id==104){g_auto=false;KillTimer(h,1);}else if(id==105)g_current=0;else if(id==106)DestroyWindow(h);InvalidateRect(h,0,TRUE);return 0;}
 if(m==WM_TIMER){if(g_auto&&g_current<g_stepCount-1){g_current++;InvalidateRect(h,0,TRUE);}else{g_auto=false;KillTimer(h,1);}return 0;}
 if(m==WM_PAINT){PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);HFONT title=CreateFontW(24,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Segoe UI");HFONT normal=CreateFontW(18,0,0,0,400,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Segoe UI");SelectObject(dc,title);RECT tr={20,15,880,50};const wchar_t* algTitle=g_algorithm==2?L"ArrayVisual - Selection Sort passo per passo":(g_algorithm==3?L"ArrayVisual - Insertion Sort passo per passo":L"ArrayVisual - Bubble Sort passo per passo");DrawTextW(dc,algTitle,-1,&tr,DT_CENTER|DT_VCENTER|DT_SINGLELINE);SelectObject(dc,normal);
 wchar_t info[80]=L"Passaggio "; wchar_t num[24];intToW(g_current,num);int p=10;for(int i=0;num[i];i++)info[p++]=num[i];info[p++]=L' ';info[p++]=L'd';info[p++]=L'i';info[p++]=L' ';intToW(g_stepCount-1,num);for(int i=0;num[i];i++)info[p++]=num[i];info[p]=0;RECT ir={20,58,880,88};DrawTextW(dc,info,-1,&ir,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
 if(g_steps&&g_current<g_stepCount){Step&s=g_steps[g_current];int gap=8;int boxW=(820-(g_n-1)*gap)/g_n;if(boxW>95)boxW=95;if(boxW<38)boxW=38;int total=g_n*boxW+(g_n-1)*gap;int sx=(900-total)/2;for(int i=0;i<g_n;i++){RECT r={sx+i*(boxW+gap),115,sx+i*(boxW+gap)+boxW,185};unsigned long col=RGBc(235,240,248);if(i==s.a||i==s.b)col=s.swapped?RGBc(188,239,196):RGBc(255,230,150);HBRUSH br=CreateSolidBrush(col);FillRect(dc,&r,br);DeleteObject(br);wchar_t val[24];if(g_charMode){val[0]=(wchar_t)s.data[i];val[1]=0;}else intToW(s.data[i],val);DrawTextW(dc,val,-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE);}
 const wchar_t* msg=L"Stato iniziale / array ordinato";if(s.a>=0)msg=s.swapped?L"Scambio eseguito: i due elementi hanno cambiato posizione":L"Confronto dei due elementi evidenziati";RECT mr={20,205,880,245};DrawTextW(dc,msg,-1,&mr,DT_CENTER|DT_VCENTER|DT_SINGLELINE);}
 DeleteObject(title);DeleteObject(normal);EndPaint(h,&ps);return 0;}
 if(m==WM_DESTROY){KillTimer(h,1);PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,wp,lp);
}

static void runWindow(){HINSTANCE inst=GetModuleHandleW(0);static bool registered=false;if(!registered){WNDCLASSEXW wc={};wc.cbSize=sizeof(wc);wc.lpfnWndProc=wndproc;wc.hInstance=inst;wc.hCursor=LoadCursorW(0,IDC_ARROW);wc.hbrBackground=(HBRUSH)(UINT_PTR)(COLOR_WINDOW+1);wc.lpszClassName=L"ArrayVisualWindowClass";RegisterClassExW(&wc);registered=true;}g_hwnd=CreateWindowExW(0,L"ArrayVisualWindowClass",L"ArrayVisual - Ordinamento visuale",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,920,410,0,0,inst,0);makeButton(g_hwnd,L"Indietro",101,80,285,110);makeButton(g_hwnd,L"Avanti",102,200,285,110);makeButton(g_hwnd,L"Automatico",103,320,285,120);makeButton(g_hwnd,L"Pausa",104,450,285,100);makeButton(g_hwnd,L"Ricomincia",105,560,285,120);makeButton(g_hwnd,L"Chiudi",106,690,285,110);ShowWindow(g_hwnd,SW_SHOW);UpdateWindow(g_hwnd);MSG msg;while(GetMessageW(&msg,0,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);} }

extern "C" __declspec(dllexport) void visualizzaOrdinamento(int valori[],int dimensione,int algoritmo){if(!valori||dimensione<1||dimensione>20)return;if(algoritmo<1||algoritmo>3)algoritmo=1;cleanup();g_algorithm=algoritmo;g_charMode=false;g_n=dimensione;buildSteps(valori,dimensione,algoritmo);runWindow();if(g_steps&&g_stepCount)for(int i=0;i<dimensione;i++)valori[i]=g_steps[g_stepCount-1].data[i];cleanup();}
extern "C" __declspec(dllexport) void visualizzaOrdinamentoChar(char valori[],int dimensione,int algoritmo){if(!valori||dimensione<1||dimensione>20)return;if(algoritmo<1||algoritmo>3)algoritmo=1;cleanup();g_algorithm=algoritmo;g_charMode=true;g_n=dimensione;int* temp=(int*)HeapAlloc(GetProcessHeap(),0,(SIZE_T)dimensione*sizeof(int));for(int i=0;i<dimensione;i++)temp[i]=(unsigned char)valori[i];buildSteps(temp,dimensione,algoritmo);HeapFree(GetProcessHeap(),0,temp);runWindow();if(g_steps&&g_stepCount)for(int i=0;i<dimensione;i++)valori[i]=(char)g_steps[g_stepCount-1].data[i];cleanup();}
extern "C" BOOL WINAPI DllMain(HINSTANCE,DWORD,void*){return TRUE;}
