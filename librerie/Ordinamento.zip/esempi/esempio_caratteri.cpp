#include <iostream>
#include "array_visual.h"
using namespace std;

int main() {
    char lettere[] = {'Z', 'B', 'M', 'A', 'C'};
    int n = sizeof(lettere) / sizeof(lettere[0]);

    // 1 = Bubble Sort, 2 = Selection Sort, 3 = Insertion Sort
    visualizzaOrdinamentoChar(lettere, n, 3);

    for (int i = 0; i < n; i++) cout << lettere[i] << " ";
    return 0;
}
