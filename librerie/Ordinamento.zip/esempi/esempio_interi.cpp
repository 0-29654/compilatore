#include <iostream>
#include "array_visual.h"
using namespace std;

int main() {
    int numeri[] = {8, 3, 6, 1, 9, 2};
    int n = sizeof(numeri) / sizeof(numeri[0]);

    // 1 = Bubble Sort, 2 = Selection Sort, 3 = Insertion Sort
    visualizzaOrdinamento(numeri, n, 2);

    for (int i = 0; i < n; i++) cout << numeri[i] << " ";
    return 0;
}
