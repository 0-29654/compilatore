@echo off
setlocal
cd /d "%~dp0"
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERRORE: g++ non trovato nel PATH.
  pause
  exit /b 1
)
g++ -shared sorgente\array_visual.cpp -Iinclude -o bin\x64\array_visual.dll -Wl,--out-implib,lib\x64\libarray_visual.dll.a -lgdi32 -luser32
if errorlevel 1 (
  echo Compilazione non riuscita.
  pause
  exit /b 1
)
echo Libreria creata correttamente.
pause
