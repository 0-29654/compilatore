#pragma once
#ifndef BINARY_SEARCH_VISUAL_CVPLUS_H
#define BINARY_SEARCH_VISUAL_CVPLUS_H

#include <string>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace binary_search_visual {

#ifdef _WIN32

class Visualizer {
public:
    Visualizer(const int* values, int count, int target)
        : data_(values, values + count), target_(target) {
        sorted_ = isSortedAscending();
        resetSearch();
    }

    int run() {
        instance_ = this;
        HINSTANCE hInst = GetModuleHandleW(nullptr);

        WNDCLASSW wc{};
        wc.lpfnWndProc = &Visualizer::WndProc;
        wc.hInstance = hInst;
        wc.lpszClassName = L"CVPLUS_BINARY_SEARCH_VISUAL_STEP";
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = CreateSolidBrush(RGB(15, 23, 42));
        RegisterClassW(&wc);

        hwnd_ = CreateWindowExW(
            WS_EX_APPWINDOW,
            wc.lpszClassName,
            L"Ricerca Binaria Visuale - Passo a passo - Copyright Alessandro Barazzuol",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1250, 760,
            nullptr, nullptr, hInst, nullptr
        );

        if (!hwnd_) return -1;

        ShowWindow(hwnd_, SW_MAXIMIZE);
        UpdateWindow(hwnd_);

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }

        instance_ = nullptr;
        return result_;
    }

private:
    static Visualizer* instance_;

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        if (!instance_) return DefWindowProcW(hwnd, msg, wp, lp);
        return instance_->handle(hwnd, msg, wp, lp);
    }

    LRESULT handle(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_CREATE:
            createButtons(hwnd);
            return 0;
        case WM_SIZE:
            layoutButtons(LOWORD(lp), HIWORD(lp));
            return 0;
        case WM_COMMAND:
            switch (LOWORD(wp)) {
            case 1001:
                nextStep();
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            case 1002:
                resetSearch();
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            case 1003:
                DestroyWindow(hwnd);
                return 0;
            }
            break;
        case WM_KEYDOWN:
            if (wp == VK_SPACE || wp == VK_RIGHT || wp == VK_RETURN) {
                nextStep();
                InvalidateRect(hwnd, nullptr, TRUE);
            } else if (wp == 'R') {
                resetSearch();
                InvalidateRect(hwnd, nullptr, TRUE);
            } else if (wp == VK_ESCAPE) {
                DestroyWindow(hwnd);
            }
            return 0;
        case WM_PAINT:
            paint(hwnd);
            return 0;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    bool isSortedAscending() const {
        for (size_t i = 1; i < data_.size(); ++i) {
            if (data_[i - 1] > data_[i]) return false;
        }
        return true;
    }

    void resetSearch() {
        result_ = -1;
        left_ = 0;
        right_ = static_cast<int>(data_.size()) - 1;
        mid_ = -1;
        step_ = 0;
        phase_ = 0;
        finished_ = false;
        found_ = false;

        if (!sorted_) {
            status_ = L"ERRORE: l'array non e' ordinato in modo crescente.";
            explanation_ =
                L"La ricerca binaria richiede un array ordinato. "
                L"Ordina prima i valori, poi riprova.";
            finished_ = true;
        } else {
            status_ = L"Array ordinato: ricerca binaria disponibile.";
            explanation_ =
                L"Premi PASSO SUCCESSIVO. La ricerca dividera' ogni volta "
                L"l'intervallo a meta'.";
        }
    }

    void nextStep() {
        if (!sorted_ || finished_) return;

        if (left_ > right_) {
            result_ = -1;
            mid_ = -1;
            finished_ = true;
            found_ = false;
            status_ = L"Ricerca terminata: valore non presente.";
            explanation_ =
                L"L'intervallo e' diventato vuoto, quindi il valore cercato "
                L"non appartiene all'array.";
            return;
        }

        if (phase_ == 0) {
            ++step_;
            mid_ = left_ + (right_ - left_) / 2;
            status_ = L"Divido l'intervallo a meta'.";
            explanation_ =
                L"Calcolo l'indice centrale: centro = sinistra + "
                L"(destra - sinistra) / 2.";
            phase_ = 1;
            return;
        }

        if (phase_ == 1) {
            const int centerValue = data_[mid_];

            if (centerValue == target_) {
                result_ = mid_;
                found_ = true;
                finished_ = true;
                status_ = L"Valore trovato!";
                explanation_ =
                    L"Il valore centrale coincide con quello cercato. "
                    L"La ricerca termina.";
                return;
            }

            if (centerValue < target_) {
                status_ = L"Il valore cercato e' maggiore del valore centrale.";
                explanation_ =
                    L"Elimino la meta' sinistra, compreso il centro, e continuo "
                    L"soltanto nella parte destra.";
                phase_ = 2;
                direction_ = 1;
            } else {
                status_ = L"Il valore cercato e' minore del valore centrale.";
                explanation_ =
                    L"Elimino la meta' destra, compreso il centro, e continuo "
                    L"soltanto nella parte sinistra.";
                phase_ = 2;
                direction_ = -1;
            }
            return;
        }

        if (phase_ == 2) {
            if (direction_ > 0) {
                left_ = mid_ + 1;
            } else {
                right_ = mid_ - 1;
            }

            if (left_ > right_) {
                result_ = -1;
                mid_ = -1;
                finished_ = true;
                found_ = false;
                status_ = L"Ricerca terminata: valore non presente.";
                explanation_ =
                    L"Non rimangono elementi da controllare.";
            } else {
                mid_ = -1;
                status_ = L"Nuovo intervallo selezionato.";
                explanation_ =
                    L"Premi di nuovo PASSO SUCCESSIVO per dividerlo a meta'.";
                phase_ = 0;
            }
        }
    }

    void createButtons(HWND hwnd) {
        HINSTANCE inst = GetModuleHandleW(nullptr);
        nextButton_ = CreateWindowW(
            L"BUTTON", L"PASSO SUCCESSIVO",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            0, 0, 190, 44, hwnd,
            reinterpret_cast<HMENU>(1001), inst, nullptr
        );
        restartButton_ = CreateWindowW(
            L"BUTTON", L"RICOMINCIA",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            0, 0, 140, 44, hwnd,
            reinterpret_cast<HMENU>(1002), inst, nullptr
        );
        closeButton_ = CreateWindowW(
            L"BUTTON", L"CHIUDI",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            0, 0, 110, 44, hwnd,
            reinterpret_cast<HMENU>(1003), inst, nullptr
        );
    }

    void layoutButtons(int width, int height) {
        MoveWindow(nextButton_, 40, height - 95, 190, 44, TRUE);
        MoveWindow(restartButton_, 245, height - 95, 140, 44, TRUE);
        MoveWindow(closeButton_, width - 150, height - 95, 110, 44, TRUE);
    }

    static void drawTextLine(HDC hdc, int x, int y, const std::wstring& text) {
        TextOutW(hdc, x, y, text.c_str(), static_cast<int>(text.size()));
    }

    void paint(HWND hwnd) {
        PAINTSTRUCT ps{};
        HDC hdc = BeginPaint(hwnd, &ps);

        RECT client{};
        GetClientRect(hwnd, &client);

        HBRUSH bg = CreateSolidBrush(RGB(15, 23, 42));
        FillRect(hdc, &client, bg);
        DeleteObject(bg);
        SetBkMode(hdc, TRANSPARENT);

        HFONT titleFont = CreateFontW(
            34, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );
        HFONT normalFont = CreateFontW(
            22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );
        HFONT smallFont = CreateFontW(
            18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );
        HFONT boldSmallFont = CreateFontW(
            18, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );

        SelectObject(hdc, titleFont);
        SetTextColor(hdc, RGB(125, 211, 252));
        drawTextLine(hdc, 38, 24, L"RICERCA BINARIA VISUALE - PASSO A PASSO");

        SelectObject(hdc, normalFont);
        SetTextColor(hdc, RGB(226, 232, 240));
        drawTextLine(hdc, 40, 82, L"Valore cercato: " + std::to_wstring(target_));
        drawTextLine(hdc, 40, 116, L"Passaggio: " + std::to_wstring(step_));

        SelectObject(hdc, boldSmallFont);
        if (!sorted_) SetTextColor(hdc, RGB(248, 113, 113));
        else if (found_) SetTextColor(hdc, RGB(74, 222, 128));
        else SetTextColor(hdc, RGB(251, 191, 36));
        drawTextLine(hdc, 40, 164, status_);

        SelectObject(hdc, smallFont);
        SetTextColor(hdc, RGB(203, 213, 225));
        drawTextLine(hdc, 40, 198, explanation_);

        if (sorted_) {
            SetTextColor(hdc, RGB(134, 239, 172));
            drawTextLine(
                hdc, 40, 230,
                L"Controllo iniziale: array ordinato in modo crescente."
            );
        } else {
            SetTextColor(hdc, RGB(248, 113, 113));
            drawTextLine(
                hdc, 40, 230,
                L"Controllo iniziale fallito: la ricerca binaria non puo' partire."
            );
        }

        const int n = static_cast<int>(data_.size());
        if (n > 0) {
            int margin = 45;
            int gap = 8;
            int available = static_cast<int>(client.right) - margin * 2;
            int calculatedCellW = (available - gap * (n - 1)) / n;
            int cellW = calculatedCellW;
            if (cellW < 42) cellW = 42;
            if (cellW > 95) cellW = 95;

            int totalW = cellW * n + gap * (n - 1);
            int centeredX = (static_cast<int>(client.right) - totalW) / 2;
            int startX = centeredX > margin ? centeredX : margin;
            int top = 320;
            int cellH = 92;

            for (int i = 0; i < n; ++i) {
                RECT r{
                    startX + i * (cellW + gap),
                    top,
                    startX + i * (cellW + gap) + cellW,
                    top + cellH
                };

                COLORREF fillColor = RGB(30, 41, 59);
                COLORREF borderColor = RGB(71, 85, 105);

                if (!sorted_) {
                    fillColor = RGB(69, 10, 10);
                    borderColor = RGB(248, 113, 113);
                } else if (finished_ && found_ && i == result_) {
                    fillColor = RGB(22, 101, 52);
                    borderColor = RGB(74, 222, 128);
                } else if (i == mid_) {
                    fillColor = RGB(124, 45, 18);
                    borderColor = RGB(251, 146, 60);
                } else if (i >= left_ && i <= right_) {
                    fillColor = RGB(30, 64, 175);
                    borderColor = RGB(96, 165, 250);
                }

                HBRUSH brush = CreateSolidBrush(fillColor);
                HPEN pen = CreatePen(PS_SOLID, 3, borderColor);
                HGDIOBJ oldBrush = SelectObject(hdc, brush);
                HGDIOBJ oldPen = SelectObject(hdc, pen);
                RoundRect(hdc, r.left, r.top, r.right, r.bottom, 16, 16);
                SelectObject(hdc, oldBrush);
                SelectObject(hdc, oldPen);
                DeleteObject(brush);
                DeleteObject(pen);

                std::wstring value = std::to_wstring(data_[i]);
                SIZE sz{};
                SelectObject(hdc, normalFont);
                SetTextColor(hdc, RGB(248, 250, 252));
                GetTextExtentPoint32W(
                    hdc, value.c_str(), static_cast<int>(value.size()), &sz
                );
                TextOutW(
                    hdc,
                    r.left + (cellW - sz.cx) / 2,
                    r.top + (cellH - sz.cy) / 2 - 5,
                    value.c_str(),
                    static_cast<int>(value.size())
                );

                std::wstring idx = L"[" + std::to_wstring(i) + L"]";
                SelectObject(hdc, smallFont);
                SetTextColor(hdc, RGB(148, 163, 184));
                GetTextExtentPoint32W(
                    hdc, idx.c_str(), static_cast<int>(idx.size()), &sz
                );
                TextOutW(
                    hdc,
                    r.left + (cellW - sz.cx) / 2,
                    r.bottom + 12,
                    idx.c_str(),
                    static_cast<int>(idx.size())
                );

                if (sorted_ && i == left_) {
                    SetTextColor(hdc, RGB(125, 211, 252));
                    drawTextLine(hdc, r.left, r.bottom + 42, L"sinistra");
                }
                if (sorted_ && i == mid_) {
                    SetTextColor(hdc, RGB(251, 146, 60));
                    drawTextLine(hdc, r.left, r.top - 30, L"centro");
                }
                if (sorted_ && i == right_) {
                    SetTextColor(hdc, RGB(196, 181, 253));
                    drawTextLine(hdc, r.left, r.bottom + 66, L"destra");
                }
            }
        }

        SelectObject(hdc, smallFont);
        SetTextColor(hdc, RGB(100, 116, 139));
        drawTextLine(
            hdc, 40, client.bottom - 132,
            L"Comandi: PASSO SUCCESSIVO, freccia destra, INVIO o SPAZIO. "
            L"R = ricomincia. ESC = chiudi."
        );
        drawTextLine(
            hdc, 40, client.bottom - 108,
            L"Copyright Alessandro Barazzuol"
        );

        DeleteObject(titleFont);
        DeleteObject(normalFont);
        DeleteObject(smallFont);
        DeleteObject(boldSmallFont);
        EndPaint(hwnd, &ps);
    }

    std::vector<int> data_;
    int target_ = 0;
    int result_ = -1;
    int left_ = 0;
    int right_ = -1;
    int mid_ = -1;
    int step_ = 0;
    int phase_ = 0;
    int direction_ = 0;
    bool sorted_ = false;
    bool finished_ = false;
    bool found_ = false;
    std::wstring status_;
    std::wstring explanation_;
    HWND hwnd_ = nullptr;
    HWND nextButton_ = nullptr;
    HWND restartButton_ = nullptr;
    HWND closeButton_ = nullptr;
};

Visualizer* Visualizer::instance_ = nullptr;

inline int visualizzaRicercaBinaria(
    const int array[], int n, int valore, int = 0
) {
    if (!array || n <= 0) return -1;
    Visualizer visualizer(array, n, valore);
    return visualizer.run();
}

inline int ricercaBinariaVisuale(
    const int array[], int n, int valore, int ritardoIgnorato = 0
) {
    return visualizzaRicercaBinaria(array, n, valore, ritardoIgnorato);
}

#else

inline int visualizzaRicercaBinaria(
    const int array[], int n, int valore, int = 0
) {
    if (!array || n <= 0) return -1;

    for (int i = 1; i < n; ++i) {
        if (array[i - 1] > array[i]) return -2;
    }

    int left = 0;
    int right = n - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (array[mid] == valore) return mid;
        if (array[mid] < valore) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

inline int ricercaBinariaVisuale(
    const int array[], int n, int valore, int parametro = 0
) {
    return visualizzaRicercaBinaria(array, n, valore, parametro);
}

#endif

} // namespace binary_search_visual

using binary_search_visual::visualizzaRicercaBinaria;
using binary_search_visual::ricercaBinariaVisuale;

#endif
