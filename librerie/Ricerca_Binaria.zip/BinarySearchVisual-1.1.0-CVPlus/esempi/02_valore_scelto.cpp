#include <iostream>
#include <binary_search_visual.h>
using namespace std;

int main() {
    int numeri[] = {3, 7, 11, 15, 20, 24, 29, 35, 42};
    int n = sizeof(numeri) / sizeof(numeri[0]);

    int valore;
    cout << "Inserisci il valore da cercare: ";
    cin >> valore;

    int posizione = visualizzaRicercaBinaria(numeri, n, valore);

    if (posizione >= 0)
        cout << "Valore trovato all'indice " << posizione << endl;
    else
        cout << "Valore non presente nell'array." << endl;

    return 0;
}
