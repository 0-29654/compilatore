#include <binary_search_visual.h>

int main() {
    int dati[] = {4, 18, 7, 25, 11};

    // La finestra spiega che la ricerca binaria non puo' partire.
    visualizzaRicercaBinaria(dati, 5, 18);

    return 0;
}
