#pragma once
#ifndef BINARY_SEARCH_VISUAL_CVPLUS_H
#define BINARY_SEARCH_VISUAL_CVPLUS_H

#include <algorithm>
#include <chrono>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace binary_search_visual {

#ifdef _WIN32

class Visualizer {
public:
    Visualizer(const int* values, int count, int target, int delayMs)
        : data_(values, values + count), target_(target), delayMs_(delayMs) {}

    int run() {
        instance_ = this;
        HINSTANCE hInst = GetModuleHandleW(nullptr);

        WNDCLASSW wc{};
        wc.lpfnWndProc = &Visualizer::WndProc;
        wc.hInstance = hInst;
        wc.lpszClassName = L"CVPLUS_BINARY_SEARCH_VISUAL";
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = CreateSolidBrush(RGB(15, 23, 42));
        RegisterClassW(&wc);

        hwnd_ = CreateWindowExW(
            WS_EX_APPWINDOW,
            wc.lpszClassName,
            L"Ricerca Binaria Visuale - Copyright Alessandro Barazzuol",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1180, 700,
            nullptr, nullptr, hInst, nullptr
        );

        if (!hwnd_) return -1;

        ShowWindow(hwnd_, SW_MAXIMIZE);
        UpdateWindow(hwnd_);

        worker_ = std::thread([this] { executeSearch(); });

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }

        closing_ = true;
        if (worker_.joinable()) worker_.join();
        instance_ = nullptr;
        return result_;
    }

private:
    static Visualizer* instance_;

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        if (!instance_) return DefWindowProcW(hwnd, msg, wp, lp);
        return instance_->handle(hwnd, msg, wp, lp);
    }

    LRESULT handle(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_PAINT:
            paint();
            return 0;
        case WM_KEYDOWN:
            if (wp == VK_ESCAPE) {
                closing_ = true;
                DestroyWindow(hwnd);
            }
            return 0;
        case WM_CLOSE:
            closing_ = true;
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        case WM_APP + 1:
            InvalidateRect(hwnd, nullptr, TRUE);
            UpdateWindow(hwnd);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    void executeSearch() {
        waitStep(700);

        int left = 0;
        int right = static_cast<int>(data_.size()) - 1;
        step_ = 0;

        while (left <= right && !closing_) {
            ++step_;
            left_ = left;
            right_ = right;
            mid_ = left + (right - left) / 2;
            found_ = false;
            finished_ = false;

            status_ = L"Confronto il valore centrale con il valore cercato";
            notify();
            waitStep(delayMs_);

            if (data_[mid_] == target_) {
                result_ = mid_;
                found_ = true;
                finished_ = true;
                status_ = L"Valore trovato: indice " + std::to_wstring(mid_);
                notify();
                return;
            }

            if (data_[mid_] < target_) {
                status_ = L"Il valore centrale e' minore: elimino la meta' sinistra";
                notify();
                waitStep(delayMs_);
                left = mid_ + 1;
            } else {
                status_ = L"Il valore centrale e' maggiore: elimino la meta' destra";
                notify();
                waitStep(delayMs_);
                right = mid_ - 1;
            }
        }

        if (!closing_) {
            result_ = -1;
            found_ = false;
            finished_ = true;
            left_ = right_ = mid_ = -1;
            status_ = L"Valore non presente nell'array";
            notify();
        }
    }

    void waitStep(int ms) {
        const int slice = 25;
        for (int elapsed = 0; elapsed < ms && !closing_; elapsed += slice)
            std::this_thread::sleep_for(std::chrono::milliseconds(slice));
    }

    void notify() {
        if (hwnd_) PostMessageW(hwnd_, WM_APP + 1, 0, 0);
    }

    void paint() {
        PAINTSTRUCT ps{};
        HDC hdc = BeginPaint(hwnd_, &ps);

        RECT client{};
        GetClientRect(hwnd_, &client);

        HBRUSH bg = CreateSolidBrush(RGB(15, 23, 42));
        FillRect(hdc, &client, bg);
        DeleteObject(bg);

        SetBkMode(hdc, TRANSPARENT);

        HFONT titleFont = CreateFontW(
            34, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );
        HFONT normalFont = CreateFontW(
            22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );
        HFONT smallFont = CreateFontW(
            17, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI"
        );

        SelectObject(hdc, titleFont);
        SetTextColor(hdc, RGB(125, 211, 252));
        TextOutW(hdc, 38, 26, L"RICERCA BINARIA VISUALE", 25);

        SelectObject(hdc, normalFont);
        SetTextColor(hdc, RGB(226, 232, 240));
        std::wstring targetLine = L"Valore cercato: " + std::to_wstring(target_);
        TextOutW(hdc, 40, 88, targetLine.c_str(), static_cast<int>(targetLine.size()));

        std::wstring stepLine = L"Passaggio: " + std::to_wstring(step_);
        TextOutW(hdc, 40, 122, stepLine.c_str(), static_cast<int>(stepLine.size()));

        SelectObject(hdc, smallFont);
        SetTextColor(hdc, RGB(148, 163, 184));
        TextOutW(hdc, 40, 164, status_.c_str(), static_cast<int>(status_.size()));

        const int n = static_cast<int>(data_.size());
        if (n > 0) {
            int margin = 45;
            int gap = 8;
            int available = client.right - margin * 2;
            int calculatedCellW = (available - gap * (n - 1)) / n;
            int cellW = calculatedCellW;
            if (cellW < 42) cellW = 42;
            if (cellW > 95) cellW = 95;
            int totalW = cellW * n + gap * (n - 1);
            int centeredX = (static_cast<int>(client.right) - totalW) / 2;
            int startX = centeredX > margin ? centeredX : margin;
            int top = 245;
            int cellH = 92;

            for (int i = 0; i < n; ++i) {
                RECT r{startX + i * (cellW + gap), top,
                       startX + i * (cellW + gap) + cellW, top + cellH};

                COLORREF fillColor = RGB(30, 41, 59);
                COLORREF borderColor = RGB(71, 85, 105);

                if (finished_ && found_ && i == result_) {
                    fillColor = RGB(22, 101, 52);
                    borderColor = RGB(74, 222, 128);
                } else if (i == mid_) {
                    fillColor = RGB(124, 45, 18);
                    borderColor = RGB(251, 146, 60);
                } else if (left_ >= 0 && right_ >= 0 && i >= left_ && i <= right_) {
                    fillColor = RGB(30, 64, 175);
                    borderColor = RGB(96, 165, 250);
                }

                HBRUSH brush = CreateSolidBrush(fillColor);
                HPEN pen = CreatePen(PS_SOLID, 3, borderColor);
                HGDIOBJ oldBrush = SelectObject(hdc, brush);
                HGDIOBJ oldPen = SelectObject(hdc, pen);
                RoundRect(hdc, r.left, r.top, r.right, r.bottom, 16, 16);
                SelectObject(hdc, oldBrush);
                SelectObject(hdc, oldPen);
                DeleteObject(brush);
                DeleteObject(pen);

                std::wstring value = std::to_wstring(data_[i]);
                SIZE sz{};
                SelectObject(hdc, normalFont);
                SetTextColor(hdc, RGB(248, 250, 252));
                GetTextExtentPoint32W(hdc, value.c_str(), static_cast<int>(value.size()), &sz);
                TextOutW(hdc, r.left + (cellW - sz.cx) / 2,
                          r.top + (cellH - sz.cy) / 2 - 5,
                          value.c_str(), static_cast<int>(value.size()));

                std::wstring idx = L"[" + std::to_wstring(i) + L"]";
                SelectObject(hdc, smallFont);
                SetTextColor(hdc, RGB(148, 163, 184));
                GetTextExtentPoint32W(hdc, idx.c_str(), static_cast<int>(idx.size()), &sz);
                TextOutW(hdc, r.left + (cellW - sz.cx) / 2,
                          r.bottom + 12, idx.c_str(), static_cast<int>(idx.size()));

                if (i == left_) {
                    SetTextColor(hdc, RGB(125, 211, 252));
                    TextOutW(hdc, r.left, r.bottom + 42, L"sinistra", 8);
                }
                if (i == mid_) {
                    SetTextColor(hdc, RGB(251, 146, 60));
                    TextOutW(hdc, r.left, r.top - 30, L"centro", 6);
                }
                if (i == right_) {
                    SetTextColor(hdc, RGB(196, 181, 253));
                    TextOutW(hdc, r.left, r.bottom + 66, L"destra", 6);
                }
            }
        }

        SelectObject(hdc, smallFont);
        SetTextColor(hdc, RGB(100, 116, 139));
        const wchar_t* footer =
            L"Premi ESC o chiudi la finestra per uscire - Copyright Alessandro Barazzuol";
        TextOutW(hdc, 40, client.bottom - 48, footer, 74);

        DeleteObject(titleFont);
        DeleteObject(normalFont);
        DeleteObject(smallFont);
        EndPaint(hwnd_, &ps);
    }

    std::vector<int> data_;
    int target_ = 0;
    int delayMs_ = 900;
    int result_ = -1;
    int left_ = -1;
    int right_ = -1;
    int mid_ = -1;
    int step_ = 0;
    bool found_ = false;
    bool finished_ = false;
    bool closing_ = false;
    std::wstring status_ = L"Preparazione della ricerca...";
    HWND hwnd_ = nullptr;
    std::thread worker_;
};

Visualizer* Visualizer::instance_ = nullptr;

inline int visualizzaRicercaBinaria(const int array[], int n, int valore, int ritardoMs = 900) {
    if (!array || n <= 0) return -1;
    Visualizer visualizer(array, n, valore, ritardoMs);
    return visualizer.run();
}

inline int ricercaBinariaVisuale(const int array[], int n, int valore, int ritardoMs = 900) {
    return visualizzaRicercaBinaria(array, n, valore, ritardoMs);
}

#else

inline int visualizzaRicercaBinaria(const int array[], int n, int valore, int = 900) {
    int left = 0, right = n - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (array[mid] == valore) return mid;
        if (array[mid] < valore) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

inline int ricercaBinariaVisuale(const int array[], int n, int valore, int ritardoMs = 900) {
    return visualizzaRicercaBinaria(array, n, valore, ritardoMs);
}

#endif

} // namespace binary_search_visual

using binary_search_visual::visualizzaRicercaBinaria;
using binary_search_visual::ricercaBinariaVisuale;

#endif
