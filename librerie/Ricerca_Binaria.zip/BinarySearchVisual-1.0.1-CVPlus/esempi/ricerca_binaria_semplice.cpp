#include <binary_search_visual.h>

int main() {
    int dati[] = {1, 4, 7, 9, 15, 18, 26, 33};

    // 1200 = durata di ogni passaggio in millisecondi
    visualizzaRicercaBinaria(dati, 8, 18, 1200);

    return 0;
}
