#include <iostream>
#include <binary_search_visual.h>
using namespace std;

int main() {
    int numeri[] = {2, 5, 8, 12, 16, 23, 31, 44, 57, 68};
    int n = sizeof(numeri) / sizeof(numeri[0]);

    int valore;
    cout << "Quale valore vuoi cercare? ";
    cin >> valore;

    int posizione = visualizzaRicercaBinaria(numeri, n, valore);

    if (posizione >= 0)
        cout << "Valore trovato all'indice " << posizione << endl;
    else
        cout << "Valore non trovato." << endl;

    return 0;
}
