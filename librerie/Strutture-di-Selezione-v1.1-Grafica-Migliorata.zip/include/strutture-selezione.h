#pragma once
#ifdef _WIN32
#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <richedit.h>
#include <string>
#include <vector>

namespace strutture_selezione {

struct Section {
    const wchar_t* title;
    const wchar_t* subtitle;
    const wchar_t* explanation;
    const wchar_t* syntax;
    const wchar_t* example;
    const wchar_t* details;
    const wchar_t* warning;
};

class GuideWindow {
    HWND hwnd_ = nullptr;
    HWND rich_ = nullptr;
    HWND header_ = nullptr;
    HWND subtitle_ = nullptr;
    std::vector<HWND> buttons_;
    const std::vector<Section>& sections_;
    HBRUSH backgroundBrush_ = nullptr;
    HBRUSH sideBrush_ = nullptr;
    HFONT buttonFont_ = nullptr;
    int selected_ = 0;

    static constexpr COLORREF BG = RGB(18, 24, 35);
    static constexpr COLORREF PANEL = RGB(25, 34, 48);
    static constexpr COLORREF SIDEBAR = RGB(31, 41, 55);
    static constexpr COLORREF TEXT = RGB(226, 232, 240);
    static constexpr COLORREF MUTED = RGB(148, 163, 184);
    static constexpr COLORREF CYAN = RGB(56, 189, 248);
    static constexpr COLORREF GREEN = RGB(74, 222, 128);
    static constexpr COLORREF AMBER = RGB(251, 191, 36);
    static constexpr COLORREF RED = RGB(248, 113, 113);
    static constexpr COLORREF CODEBG = RGB(12, 18, 28);

    static LRESULT CALLBACK Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        GuideWindow* self = reinterpret_cast<GuideWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            auto cs = reinterpret_cast<CREATESTRUCTW*>(lp);
            self = static_cast<GuideWindow*>(cs->lpCreateParams);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
            self->hwnd_ = hwnd;
        }
        if (!self) return DefWindowProcW(hwnd, msg, wp, lp);

        switch (msg) {
            case WM_CREATE:
                self->createControls();
                return 0;
            case WM_COMMAND:
                if (HIWORD(wp) == BN_CLICKED) {
                    const int id = LOWORD(wp) - 1000;
                    if (id >= 0 && id < static_cast<int>(self->sections_.size())) {
                        self->selected_ = id;
                        self->showSection(id);
                        InvalidateRect(self->hwnd_, nullptr, TRUE);
                    }
                }
                return 0;
            case WM_CTLCOLORSTATIC: {
                HDC dc = reinterpret_cast<HDC>(wp);
                HWND control = reinterpret_cast<HWND>(lp);
                SetBkMode(dc, TRANSPARENT);
                if (control == self->header_) SetTextColor(dc, CYAN);
                else SetTextColor(dc, MUTED);
                return reinterpret_cast<INT_PTR>(self->backgroundBrush_);
            }
            case WM_CTLCOLORBTN: {
                HDC dc = reinterpret_cast<HDC>(wp);
                SetBkColor(dc, SIDEBAR);
                SetTextColor(dc, TEXT);
                return reinterpret_cast<INT_PTR>(self->sideBrush_);
            }
            case WM_ERASEBKGND: {
                RECT r{};
                GetClientRect(hwnd, &r);
                FillRect(reinterpret_cast<HDC>(wp), &r, self->backgroundBrush_);
                RECT side = r;
                side.right = 250;
                FillRect(reinterpret_cast<HDC>(wp), &side, self->sideBrush_);
                return 1;
            }
            case WM_SIZE:
                self->layout(LOWORD(lp), HIWORD(lp));
                return 0;
            case WM_CLOSE:
                DestroyWindow(hwnd);
                return 0;
            case WM_DESTROY:
                if (self->buttonFont_) DeleteObject(self->buttonFont_);
                if (self->backgroundBrush_) DeleteObject(self->backgroundBrush_);
                if (self->sideBrush_) DeleteObject(self->sideBrush_);
                PostQuitMessage(0);
                return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    static HFONT makeFont(int size, int weight, const wchar_t* face) {
        HDC dc = GetDC(nullptr);
        const int height = -MulDiv(size, GetDeviceCaps(dc, LOGPIXELSY), 72);
        ReleaseDC(nullptr, dc);
        return CreateFontW(height, 0, 0, 0, weight, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
    }

    void createControls() {
        backgroundBrush_ = CreateSolidBrush(BG);
        sideBrush_ = CreateSolidBrush(SIDEBAR);
        buttonFont_ = makeFont(11, FW_SEMIBOLD, L"Segoe UI");

        header_ = CreateWindowW(L"STATIC", L"SELEZIONE C++", WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        subtitle_ = CreateWindowW(L"STATIC", L"Guida visuale interattiva", WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        HFONT titleFont = makeFont(22, FW_BOLD, L"Segoe UI");
        HFONT subtitleFont = makeFont(10, FW_NORMAL, L"Segoe UI");
        SendMessageW(header_, WM_SETFONT, reinterpret_cast<WPARAM>(titleFont), TRUE);
        SendMessageW(subtitle_, WM_SETFONT, reinterpret_cast<WPARAM>(subtitleFont), TRUE);

        for (size_t i = 0; i < sections_.size(); ++i) {
            HWND b = CreateWindowW(L"BUTTON", sections_[i].title,
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_FLAT,
                0, 0, 0, 0, hwnd_, reinterpret_cast<HMENU>(1000 + i),
                GetModuleHandleW(nullptr), nullptr);
            SendMessageW(b, WM_SETFONT, reinterpret_cast<WPARAM>(buttonFont_), TRUE);
            buttons_.push_back(b);
        }

        LoadLibraryW(L"Msftedit.dll");
        rich_ = CreateWindowExW(0, MSFTEDIT_CLASS, L"",
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        SendMessageW(rich_, EM_SETBKGNDCOLOR, 0, PANEL);
        SendMessageW(rich_, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(24, 24));
        SendMessageW(rich_, EM_SETREADONLY, TRUE, 0);

        RECT r{};
        GetClientRect(hwnd_, &r);
        layout(r.right, r.bottom);
        showSection(0);
    }

    void layout(int w, int h) {
        const int side = 250;
        const int margin = 18;
        const int buttonH = 48;
        MoveWindow(header_, margin, 20, side - margin * 2, 34, TRUE);
        MoveWindow(subtitle_, margin, 56, side - margin * 2, 24, TRUE);

        int y = 100;
        for (HWND b : buttons_) {
            MoveWindow(b, margin, y, side - margin * 2, buttonH, TRUE);
            y += buttonH + 10;
        }
        MoveWindow(rich_, side + 18, 18, w - side - 36, h - 36, TRUE);
    }

    void setFormat(COLORREF color, int size, int weight, const wchar_t* face,
                   COLORREF back = PANEL, bool italic = false, bool underline = false) {
        CHARFORMAT2W cf{};
        cf.cbSize = sizeof(cf);
        cf.dwMask = CFM_COLOR | CFM_SIZE | CFM_FACE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE | CFM_BACKCOLOR;
        cf.crTextColor = color;
        cf.crBackColor = back;
        cf.yHeight = size * 20;
        cf.dwEffects = 0;
        if (weight >= FW_BOLD) cf.dwEffects |= CFE_BOLD;
        if (italic) cf.dwEffects |= CFE_ITALIC;
        if (underline) cf.dwEffects |= CFE_UNDERLINE;
        wcsncpy_s(cf.szFaceName, face, _TRUNCATE);
        SendMessageW(rich_, EM_SETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&cf));
    }

    void append(const wchar_t* text, COLORREF color = TEXT, int size = 11,
                int weight = FW_NORMAL, const wchar_t* face = L"Segoe UI",
                COLORREF back = PANEL, bool italic = false) {
        const LRESULT len = SendMessageW(rich_, WM_GETTEXTLENGTH, 0, 0);
        SendMessageW(rich_, EM_SETSEL, len, len);
        setFormat(color, size, weight, face, back, italic);
        SendMessageW(rich_, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(text));
    }

    void label(const wchar_t* text, COLORREF color) {
        append(L"\r\n", TEXT, 5);
        append(text, color, 10, FW_BOLD, L"Segoe UI");
        append(L"\r\n", TEXT, 5);
    }

    void codeBlock(const wchar_t* code) {
        append(L"  ", TEXT, 10, FW_NORMAL, L"Consolas", CODEBG);
        std::wstring indented;
        for (const wchar_t* p = code; *p; ++p) {
            indented.push_back(*p);
            if (*p == L'\n') indented += L"  ";
        }
        append(indented.c_str(), RGB(203, 213, 225), 11, FW_NORMAL, L"Consolas", CODEBG);
        append(L"\r\n", TEXT, 6);
    }

    void showSection(int i) {
        SendMessageW(rich_, WM_SETREDRAW, FALSE, 0);
        SetWindowTextW(rich_, L"");
        const Section& s = sections_[i];

        append(s.title, CYAN, 24, FW_BOLD, L"Segoe UI");
        append(L"\r\n", TEXT, 4);
        append(s.subtitle, MUTED, 12, FW_NORMAL, L"Segoe UI", PANEL, true);
        append(L"\r\n\r\n", TEXT, 6);

        append(s.explanation, TEXT, 12, FW_NORMAL, L"Segoe UI");
        append(L"\r\n", TEXT, 5);

        label(L"SINTASSI", GREEN);
        codeBlock(s.syntax);

        label(L"ESEMPIO COMPLETO", CYAN);
        codeBlock(s.example);

        label(L"COME FUNZIONA", AMBER);
        append(s.details, TEXT, 11, FW_NORMAL, L"Segoe UI");
        append(L"\r\n", TEXT, 5);

        if (s.warning && *s.warning) {
            label(L"ATTENZIONE", RED);
            append(L"  ", TEXT, 11, FW_NORMAL, L"Segoe UI", RGB(56, 28, 32));
            append(s.warning, RGB(254, 202, 202), 11, FW_SEMIBOLD, L"Segoe UI", RGB(56, 28, 32));
            append(L"  \r\n", TEXT, 8, FW_NORMAL, L"Segoe UI", RGB(56, 28, 32));
        }

        SendMessageW(rich_, EM_SETSEL, 0, 0);
        SendMessageW(rich_, EM_SCROLLCARET, 0, 0);
        SendMessageW(rich_, WM_SETREDRAW, TRUE, 0);
        InvalidateRect(rich_, nullptr, TRUE);
    }

public:
    explicit GuideWindow(const std::vector<Section>& s) : sections_(s) {}

    int run(const wchar_t* title) {
        HINSTANCE h = GetModuleHandleW(nullptr);
        const wchar_t* cls = L"CVPlus_strutture_selezione_v2";
        WNDCLASSW wc{};
        wc.lpfnWndProc = Proc;
        wc.hInstance = h;
        wc.lpszClassName = cls;
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        wc.hbrBackground = CreateSolidBrush(BG);
        wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
        RegisterClassW(&wc);

        HWND win = CreateWindowExW(0, cls, title,
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1100, 720,
            nullptr, nullptr, h, this);
        if (!win) return -1;

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        return 0;
    }
};

inline int mostra_guida() {
    static const std::vector<Section> sections = {
        {
            L"IF SEMPLICE",
            L"Esegue un blocco soltanto quando la condizione è vera",
            L"L'istruzione if permette al programma di prendere una decisione. Prima viene valutata una condizione logica; se il risultato è vero, il blocco tra graffe viene eseguito. Se è falso, il programma salta il blocco e continua con l'istruzione successiva.",
            L"if (condizione) {\r\n    // istruzioni eseguite se vero\r\n}",
            L"int temperatura = 28;\r\n\r\nif (temperatura > 25) {\r\n    cout << \"Fa caldo\" << endl;\r\n}",
            L"1. Il programma legge il valore di temperatura.\r\n2. Controlla se 28 è maggiore di 25.\r\n3. La condizione è vera.\r\n4. Viene stampato il messaggio Fa caldo.\r\n5. Il programma prosegue dopo la graffa finale.",
            L"Nel confronto usa == per verificare l'uguaglianza. Il simbolo = serve invece ad assegnare un valore."
        },
        {
            L"IF SENZA ELSE",
            L"Una scelta a senso unico, senza comportamento alternativo",
            L"Non è obbligatorio aggiungere else. Questa forma è utile quando vuoi eseguire un'azione solo in una situazione particolare, mentre in tutti gli altri casi il programma deve semplicemente continuare.",
            L"if (condizione) {\r\n    // azione facoltativa\r\n}\r\n\r\n// il programma continua qui",
            L"int eta = 20;\r\n\r\nif (eta >= 18) {\r\n    cout << \"Accesso consentito\" << endl;\r\n}\r\n\r\ncout << \"Controllo terminato\";",
            L"Se eta è almeno 18, viene mostrato Accesso consentito. In ogni caso, dopo l'if viene eseguita la stampa Controllo terminato. L'assenza di else non interrompe il programma.",
            L"Senza graffe, l'if controlla una sola istruzione. Per evitare errori e rendere il codice più chiaro, è consigliabile usare sempre le graffe."
        },
        {
            L"IF - ELSE",
            L"Sceglie una sola strada tra due alternative",
            L"La struttura if-else rappresenta una decisione completa. Se la condizione è vera viene eseguito il primo blocco; altrimenti viene eseguito il blocco else. I due blocchi sono alternativi: non possono essere eseguiti entrambi nello stesso passaggio.",
            L"if (condizione) {\r\n    // caso vero\r\n} else {\r\n    // caso falso\r\n}",
            L"int voto = 7;\r\n\r\nif (voto >= 6) {\r\n    cout << \"Promosso\";\r\n} else {\r\n    cout << \"Da recuperare\";\r\n}",
            L"Il programma confronta voto con 6. Poiché 7 >= 6 è vero, stampa Promosso e salta completamente il blocco else. Con voto uguale a 5 avrebbe eseguito soltanto il secondo blocco.",
            L"Non scrivere una nuova condizione dopo else. Se serve un'altra condizione, devi usare else if."
        },
        {
            L"IF - ELSE IF - ELSE",
            L"Gestisce più casi controllandoli dall'alto verso il basso",
            L"Una catena di else if permette di classificare un valore in più categorie. Le condizioni vengono valutate nell'ordine in cui sono scritte. Appena una risulta vera, il relativo blocco viene eseguito e tutte le condizioni successive vengono ignorate.",
            L"if (condizione1) {\r\n    // primo caso\r\n} else if (condizione2) {\r\n    // secondo caso\r\n} else {\r\n    // tutti gli altri casi\r\n}",
            L"int voto = 8;\r\n\r\nif (voto >= 9) {\r\n    cout << \"Ottimo\";\r\n} else if (voto >= 7) {\r\n    cout << \"Buono\";\r\n} else if (voto >= 6) {\r\n    cout << \"Sufficiente\";\r\n} else {\r\n    cout << \"Insufficiente\";\r\n}",
            L"Con voto uguale a 8, la prima condizione è falsa ma voto >= 7 è vera. Il programma stampa Buono e non controlla più voto >= 6. Per questo le condizioni devono essere ordinate dal caso più restrittivo al più generale.",
            L"Se mettessi prima voto >= 6, anche i voti 7, 8, 9 e 10 entrerebbero subito nel primo caso e le categorie superiori non verrebbero mai raggiunte."
        },
        {
            L"CONDIZIONI COMPOSTE",
            L"Combina più controlli con AND, OR e NOT",
            L"Gli operatori logici permettono di costruire condizioni più precise. && richiede che entrambe le condizioni siano vere; || richiede che almeno una sia vera; ! inverte il risultato logico.",
            L"if (A && B) { /* entrambe vere */ }\r\nif (A || B) { /* almeno una vera */ }\r\nif (!A)     { /* A è falsa */ }",
            L"int eta = 16;\r\nbool autorizzazione = true;\r\n\r\nif (eta >= 14 && autorizzazione) {\r\n    cout << \"Partecipazione consentita\";\r\n}",
            L"Il primo confronto verifica che l'età sia almeno 14. Il secondo controlla l'autorizzazione. Poiché entrambe le condizioni sono vere, l'intera espressione con && è vera e il messaggio viene stampato.",
            L"Usa le parentesi quando combini molte condizioni: rendono evidente l'ordine logico e riducono gli errori di interpretazione."
        },
        {
            L"SWITCH",
            L"Seleziona un caso confrontando un valore con costanti precise",
            L"switch è adatto quando una stessa variabile può assumere diversi valori discreti, come numeri di menu, caratteri o enumerazioni. Ogni case rappresenta un valore possibile; default gestisce tutti i valori non previsti.",
            L"switch (valore) {\r\n    case 1:\r\n        // istruzioni\r\n        break;\r\n    default:\r\n        // caso non previsto\r\n}",
            L"int scelta = 2;\r\n\r\nswitch (scelta) {\r\n    case 1:\r\n        cout << \"Nuova partita\";\r\n        break;\r\n    case 2:\r\n        cout << \"Carica partita\";\r\n        break;\r\n    default:\r\n        cout << \"Scelta non valida\";\r\n}",
            L"switch legge il valore 2 e salta direttamente al case 2. Stampa Carica partita. L'istruzione break fa uscire dalla struttura, impedendo l'esecuzione dei casi successivi.",
            L"Dimenticare break provoca il fall-through: il programma continua anche nei case seguenti. Può essere voluto, ma deve essere usato consapevolmente."
        },
        {
            L"ERRORI COMUNI",
            L"Gli sbagli più frequenti nelle strutture di selezione",
            L"Gli errori nelle selezioni spesso non impediscono la compilazione, ma producono decisioni sbagliate. È quindi importante verificare le condizioni con esempi concreti e con i valori limite.",
            L"// Controlla sempre:\r\n// 1. operatori di confronto\r\n// 2. ordine degli else if\r\n// 3. parentesi e graffe\r\n// 4. break nello switch",
            L"int numero = 10;\r\n\r\nif (numero > 0 && numero <= 100) {\r\n    cout << \"Valore valido\";\r\n} else {\r\n    cout << \"Fuori intervallo\";\r\n}",
            L"• = al posto di == modifica la variabile invece di confrontarla.\r\n• Condizioni in ordine errato rendono alcuni rami irraggiungibili.\r\n• Un punto e virgola subito dopo if chiude accidentalmente l'istruzione.\r\n• Condizioni sovrapposte possono classificare male i valori limite.\r\n• break mancante nello switch esegue i casi successivi.",
            L"Prova sempre i valori ai confini: per voto >= 6 verifica almeno 5, 6 e 7. È il modo più semplice per scoprire errori con <, <=, > e >=."
        }
    };

    GuideWindow window(sections);
    return window.run(L"Strutture di selezione C++ — if e switch");
}

} // namespace strutture_selezione
#else
#include <iostream>
namespace strutture_selezione {
inline int mostra_guida() {
    std::cout << "Questa guida visuale richiede Windows." << std::endl;
    return 0;
}
}
#endif
