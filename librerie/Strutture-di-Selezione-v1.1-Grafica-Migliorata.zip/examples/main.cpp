#include <strutture-selezione.h>

int main() {
    strutture_selezione::mostra_guida();
    return 0;
}
