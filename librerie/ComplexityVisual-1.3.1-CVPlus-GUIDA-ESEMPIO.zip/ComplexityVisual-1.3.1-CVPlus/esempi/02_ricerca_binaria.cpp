#include <complexity_visual.h>

int main() {
    visualizzaComplessita(ESEMPIO_RICERCA_BINARIA);
    return 0;
}
