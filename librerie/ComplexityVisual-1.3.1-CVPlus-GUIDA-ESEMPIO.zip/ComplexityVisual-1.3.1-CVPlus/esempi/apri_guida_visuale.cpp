#include <complexity_visual.h>

int main() {
    apriComplessitaVisuale();
    return 0;
}
