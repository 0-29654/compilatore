#include <complexity_visual.h>

int main() {
    // Cambia il parametro per scegliere l'algoritmo da analizzare.
    visualizzaComplessita(ESEMPIO_BUBBLE_SORT);
    return 0;
}
