#include <complexity_visual.h>

int main() {
    // Apre l'elenco completo di tutti gli esempi.
    apriCatalogoComplessita();
    return 0;
}
