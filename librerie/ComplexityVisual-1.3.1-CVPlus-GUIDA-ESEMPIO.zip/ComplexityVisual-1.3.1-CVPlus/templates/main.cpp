#include <complexity_visual.h>

int main()
{
    apriCatalogoComplessita();
    return 0;
}
