#include <cicli-while-for.h>

int main() {
    cicli_while_for::mostra_guida();
    return 0;
}
