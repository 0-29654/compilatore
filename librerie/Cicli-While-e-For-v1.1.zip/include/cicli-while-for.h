#pragma once
#ifdef _WIN32
#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <richedit.h>
#include <string>
#include <vector>

namespace cicli_while_for {

struct Section {
    const wchar_t* title;
    const wchar_t* subtitle;
    const wchar_t* explanation;
    const wchar_t* syntax;
    const wchar_t* example;
    const wchar_t* details;
    const wchar_t* warning;
};

class GuideWindow {
    HWND hwnd_ = nullptr;
    HWND rich_ = nullptr;
    HWND header_ = nullptr;
    HWND subtitle_ = nullptr;
    std::vector<HWND> buttons_;
    const std::vector<Section>& sections_;
    HBRUSH backgroundBrush_ = nullptr;
    HBRUSH sideBrush_ = nullptr;
    HFONT buttonFont_ = nullptr;
    int selected_ = 0;

    static constexpr COLORREF BG = RGB(18, 24, 35);
    static constexpr COLORREF PANEL = RGB(25, 34, 48);
    static constexpr COLORREF SIDEBAR = RGB(31, 41, 55);
    static constexpr COLORREF TEXT = RGB(226, 232, 240);
    static constexpr COLORREF MUTED = RGB(148, 163, 184);
    static constexpr COLORREF CYAN = RGB(56, 189, 248);
    static constexpr COLORREF GREEN = RGB(74, 222, 128);
    static constexpr COLORREF AMBER = RGB(251, 191, 36);
    static constexpr COLORREF RED = RGB(248, 113, 113);
    static constexpr COLORREF CODEBG = RGB(12, 18, 28);

    static LRESULT CALLBACK Proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        GuideWindow* self = reinterpret_cast<GuideWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            auto cs = reinterpret_cast<CREATESTRUCTW*>(lp);
            self = static_cast<GuideWindow*>(cs->lpCreateParams);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
            self->hwnd_ = hwnd;
        }
        if (!self) return DefWindowProcW(hwnd, msg, wp, lp);

        switch (msg) {
            case WM_CREATE:
                self->createControls();
                return 0;
            case WM_COMMAND:
                if (HIWORD(wp) == BN_CLICKED) {
                    const int id = LOWORD(wp) - 1000;
                    if (id >= 0 && id < static_cast<int>(self->sections_.size())) {
                        self->selected_ = id;
                        self->showSection(id);
                        InvalidateRect(self->hwnd_, nullptr, TRUE);
                    }
                }
                return 0;
            case WM_CTLCOLORSTATIC: {
                HDC dc = reinterpret_cast<HDC>(wp);
                HWND control = reinterpret_cast<HWND>(lp);
                SetBkMode(dc, TRANSPARENT);
                if (control == self->header_) SetTextColor(dc, CYAN);
                else SetTextColor(dc, MUTED);
                return reinterpret_cast<INT_PTR>(self->backgroundBrush_);
            }
            case WM_CTLCOLORBTN: {
                HDC dc = reinterpret_cast<HDC>(wp);
                SetBkColor(dc, SIDEBAR);
                SetTextColor(dc, TEXT);
                return reinterpret_cast<INT_PTR>(self->sideBrush_);
            }
            case WM_ERASEBKGND: {
                RECT r{};
                GetClientRect(hwnd, &r);
                FillRect(reinterpret_cast<HDC>(wp), &r, self->backgroundBrush_);
                RECT side = r;
                side.right = 250;
                FillRect(reinterpret_cast<HDC>(wp), &side, self->sideBrush_);
                return 1;
            }
            case WM_SIZE:
                self->layout(LOWORD(lp), HIWORD(lp));
                return 0;
            case WM_CLOSE:
                DestroyWindow(hwnd);
                return 0;
            case WM_DESTROY:
                if (self->buttonFont_) DeleteObject(self->buttonFont_);
                if (self->backgroundBrush_) DeleteObject(self->backgroundBrush_);
                if (self->sideBrush_) DeleteObject(self->sideBrush_);
                PostQuitMessage(0);
                return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    static HFONT makeFont(int size, int weight, const wchar_t* face) {
        HDC dc = GetDC(nullptr);
        const int height = -MulDiv(size, GetDeviceCaps(dc, LOGPIXELSY), 72);
        ReleaseDC(nullptr, dc);
        return CreateFontW(height, 0, 0, 0, weight, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
    }

    void createControls() {
        backgroundBrush_ = CreateSolidBrush(BG);
        sideBrush_ = CreateSolidBrush(SIDEBAR);
        buttonFont_ = makeFont(11, FW_SEMIBOLD, L"Segoe UI");

        header_ = CreateWindowW(L"STATIC", L"CICLI C++", WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        subtitle_ = CreateWindowW(L"STATIC", L"Guida visuale interattiva", WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        HFONT titleFont = makeFont(22, FW_BOLD, L"Segoe UI");
        HFONT subtitleFont = makeFont(10, FW_NORMAL, L"Segoe UI");
        SendMessageW(header_, WM_SETFONT, reinterpret_cast<WPARAM>(titleFont), TRUE);
        SendMessageW(subtitle_, WM_SETFONT, reinterpret_cast<WPARAM>(subtitleFont), TRUE);

        for (size_t i = 0; i < sections_.size(); ++i) {
            HWND b = CreateWindowW(L"BUTTON", sections_[i].title,
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_FLAT,
                0, 0, 0, 0, hwnd_, reinterpret_cast<HMENU>(1000 + i),
                GetModuleHandleW(nullptr), nullptr);
            SendMessageW(b, WM_SETFONT, reinterpret_cast<WPARAM>(buttonFont_), TRUE);
            buttons_.push_back(b);
        }

        LoadLibraryW(L"Msftedit.dll");
        rich_ = CreateWindowExW(0, MSFTEDIT_CLASS, L"",
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
            0, 0, 0, 0, hwnd_, nullptr, GetModuleHandleW(nullptr), nullptr);
        SendMessageW(rich_, EM_SETBKGNDCOLOR, 0, PANEL);
        SendMessageW(rich_, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(24, 24));
        SendMessageW(rich_, EM_SETREADONLY, TRUE, 0);

        RECT r{};
        GetClientRect(hwnd_, &r);
        layout(r.right, r.bottom);
        showSection(0);
    }

    void layout(int w, int h) {
        const int side = 250;
        const int margin = 18;
        const int buttonH = 48;
        MoveWindow(header_, margin, 20, side - margin * 2, 34, TRUE);
        MoveWindow(subtitle_, margin, 56, side - margin * 2, 24, TRUE);

        int y = 100;
        for (HWND b : buttons_) {
            MoveWindow(b, margin, y, side - margin * 2, buttonH, TRUE);
            y += buttonH + 10;
        }
        MoveWindow(rich_, side + 18, 18, w - side - 36, h - 36, TRUE);
    }

    void setFormat(COLORREF color, int size, int weight, const wchar_t* face,
                   COLORREF back = PANEL, bool italic = false, bool underline = false) {
        CHARFORMAT2W cf{};
        cf.cbSize = sizeof(cf);
        cf.dwMask = CFM_COLOR | CFM_SIZE | CFM_FACE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE | CFM_BACKCOLOR;
        cf.crTextColor = color;
        cf.crBackColor = back;
        cf.yHeight = size * 20;
        cf.dwEffects = 0;
        if (weight >= FW_BOLD) cf.dwEffects |= CFE_BOLD;
        if (italic) cf.dwEffects |= CFE_ITALIC;
        if (underline) cf.dwEffects |= CFE_UNDERLINE;
        wcsncpy_s(cf.szFaceName, face, _TRUNCATE);
        SendMessageW(rich_, EM_SETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&cf));
    }

    void append(const wchar_t* text, COLORREF color = TEXT, int size = 11,
                int weight = FW_NORMAL, const wchar_t* face = L"Segoe UI",
                COLORREF back = PANEL, bool italic = false) {
        const LRESULT len = SendMessageW(rich_, WM_GETTEXTLENGTH, 0, 0);
        SendMessageW(rich_, EM_SETSEL, len, len);
        setFormat(color, size, weight, face, back, italic);
        SendMessageW(rich_, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(text));
    }

    void label(const wchar_t* text, COLORREF color) {
        append(L"\r\n", TEXT, 5);
        append(text, color, 10, FW_BOLD, L"Segoe UI");
        append(L"\r\n", TEXT, 5);
    }

    void codeBlock(const wchar_t* code) {
        append(L"  ", TEXT, 10, FW_NORMAL, L"Consolas", CODEBG);
        std::wstring indented;
        for (const wchar_t* p = code; *p; ++p) {
            indented.push_back(*p);
            if (*p == L'\n') indented += L"  ";
        }
        append(indented.c_str(), RGB(203, 213, 225), 11, FW_NORMAL, L"Consolas", CODEBG);
        append(L"\r\n", TEXT, 6);
    }

    void showSection(int i) {
        SendMessageW(rich_, WM_SETREDRAW, FALSE, 0);
        SetWindowTextW(rich_, L"");
        const Section& s = sections_[i];

        append(s.title, CYAN, 24, FW_BOLD, L"Segoe UI");
        append(L"\r\n", TEXT, 4);
        append(s.subtitle, MUTED, 12, FW_NORMAL, L"Segoe UI", PANEL, true);
        append(L"\r\n\r\n", TEXT, 6);

        append(s.explanation, TEXT, 12, FW_NORMAL, L"Segoe UI");
        append(L"\r\n", TEXT, 5);

        label(L"SINTASSI", GREEN);
        codeBlock(s.syntax);

        label(L"ESEMPIO COMPLETO", CYAN);
        codeBlock(s.example);

        label(L"COME FUNZIONA", AMBER);
        append(s.details, TEXT, 11, FW_NORMAL, L"Segoe UI");
        append(L"\r\n", TEXT, 5);

        if (s.warning && *s.warning) {
            label(L"ATTENZIONE", RED);
            append(L"  ", TEXT, 11, FW_NORMAL, L"Segoe UI", RGB(56, 28, 32));
            append(s.warning, RGB(254, 202, 202), 11, FW_SEMIBOLD, L"Segoe UI", RGB(56, 28, 32));
            append(L"  \r\n", TEXT, 8, FW_NORMAL, L"Segoe UI", RGB(56, 28, 32));
        }

        SendMessageW(rich_, EM_SETSEL, 0, 0);
        SendMessageW(rich_, EM_SCROLLCARET, 0, 0);
        SendMessageW(rich_, WM_SETREDRAW, TRUE, 0);
        InvalidateRect(rich_, nullptr, TRUE);
    }

public:
    explicit GuideWindow(const std::vector<Section>& s) : sections_(s) {}

    int run(const wchar_t* title) {
        HINSTANCE h = GetModuleHandleW(nullptr);
        const wchar_t* cls = L"CVPlus_cicli_while_for_v2";
        WNDCLASSW wc{};
        wc.lpfnWndProc = Proc;
        wc.hInstance = h;
        wc.lpszClassName = cls;
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        wc.hbrBackground = CreateSolidBrush(BG);
        wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
        RegisterClassW(&wc);

        HWND win = CreateWindowExW(0, cls, title,
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1100, 720,
            nullptr, nullptr, h, this);
        if (!win) return -1;

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        return 0;
    }
};

inline int mostra_guida() {
    static const std::vector<Section> sections = {
        {
            L"WHILE",
            L"Ripete un blocco finché una condizione rimane vera",
            L"Il ciclo while è ideale quando non conosci in anticipo quante volte dovrai ripetere le istruzioni. La condizione viene controllata prima di ogni iterazione: se è falsa già all'inizio, il blocco non viene eseguito.",
            L"while (condizione) {\r\n    // istruzioni da ripetere\r\n}",
            L"int i = 0;\r\n\r\nwhile (i < 5) {\r\n    cout << i << endl;\r\n    i++;\r\n}",
            L"1. i parte da 0.\r\n2. Il programma verifica i < 5.\r\n3. Stampa il valore corrente.\r\n4. i++ aumenta il contatore.\r\n5. Quando i diventa 5, la condizione è falsa e il ciclo termina.",
            L"La variabile usata nella condizione deve cambiare all'interno del ciclo. Altrimenti puoi creare un ciclo infinito."
        },
        {
            L"DO - WHILE",
            L"Esegue il blocco almeno una volta e controlla dopo",
            L"Il ciclo do-while è utile per menu, controlli dell'input e operazioni che devono essere eseguite almeno una volta. La condizione si trova alla fine del blocco.",
            L"do {\r\n    // istruzioni\r\n} while (condizione);",
            L"int scelta;\r\n\r\ndo {\r\n    cout << \"Scegli da 1 a 3: \";\r\n    cin >> scelta;\r\n} while (scelta < 1 || scelta > 3);",
            L"Il programma chiede una scelta. Se il valore è minore di 1 oppure maggiore di 3, ripete la domanda. Appena il valore è valido, il ciclo termina.",
            L"Dopo la parentesi del while finale è obbligatorio il punto e virgola."
        },
        {
            L"FOR",
            L"Compatto e preciso quando conosci il numero di ripetizioni",
            L"Il ciclo for riunisce in una sola riga l'inizializzazione, la condizione e l'aggiornamento. È la scelta più comune per contatori, array, vettori e ripetizioni con un numero noto di passaggi.",
            L"for (inizializzazione; condizione; aggiornamento) {\r\n    // istruzioni\r\n}",
            L"for (int i = 0; i < 10; i++) {\r\n    cout << \"Passo \" << i << endl;\r\n}",
            L"int i = 0 viene eseguito una sola volta. Prima di ogni giro si controlla i < 10. Alla fine di ogni iterazione viene eseguito i++. Il ciclo stampa i valori da 0 a 9.",
            L"Con i < 10 l'ultimo valore è 9. Usando i <= 10 avresti invece 11 iterazioni, da 0 a 10."
        },
        {
            L"FOR ANNIDATO",
            L"Un ciclo dentro un altro per righe, colonne e combinazioni",
            L"I cicli annidati servono quando ogni elemento esterno richiede una nuova sequenza interna. Sono frequenti nelle matrici, nelle tabelle, nei disegni con caratteri e nel confronto tra coppie di elementi.",
            L"for (...) {\r\n    for (...) {\r\n        // istruzioni interne\r\n    }\r\n}",
            L"for (int r = 0; r < 3; r++) {\r\n    for (int c = 0; c < 4; c++) {\r\n        cout << \"[\" << r << \",\" << c << \"] \";\r\n    }\r\n    cout << endl;\r\n}",
            L"Il ciclo esterno gestisce le 3 righe. Per ogni riga, il ciclo interno percorre 4 colonne. Le istruzioni interne vengono quindi eseguite 3 × 4 = 12 volte.",
            L"Il numero totale di iterazioni cresce moltiplicando i cicli. Due cicli molto grandi possono rallentare sensibilmente il programma."
        },
        {
            L"BREAK E CONTINUE",
            L"Controllano in modo immediato il flusso del ciclo",
            L"break interrompe completamente il ciclo. continue salta soltanto il resto dell'iterazione corrente e passa alla successiva. Sono utili, ma vanno usati con chiarezza.",
            L"break;       // termina il ciclo\r\ncontinue;    // passa al giro successivo",
            L"for (int i = 1; i <= 10; i++) {\r\n    if (i == 3) continue;\r\n    if (i == 8) break;\r\n    cout << i << \" \";\r\n}",
            L"Quando i vale 3, continue evita la stampa. Quando i vale 8, break termina il ciclo. L'output sarà: 1 2 4 5 6 7.",
            L"Un uso eccessivo di break e continue può rendere il percorso del programma più difficile da seguire."
        },
        {
            L"ERRORI COMUNI",
            L"I problemi più frequenti nei cicli e come evitarli",
            L"Molti errori nei cicli dipendono da una condizione sbagliata, da un contatore non aggiornato oppure da limiti non compatibili con gli indici di un array.",
            L"// Controlla sempre:\r\n// 1. valore iniziale\r\n// 2. condizione di uscita\r\n// 3. aggiornamento",
            L"int somma = 0;\r\n\r\nfor (int i = 0; i < 5; i++) {\r\n    somma += i;\r\n}\r\n\r\ncout << somma;",
            L"• Ciclo infinito: la condizione resta sempre vera.\r\n• Errore di uno: usare <= al posto di <.\r\n• Indice fuori limite: accedere a una posizione inesistente.\r\n• Accumulatore non inizializzato: la somma parte da un valore indefinito.\r\n• Modifica doppia del contatore: incremento sia nel for sia nel corpo.",
            L"Prima di eseguire il programma, prova a simulare a mano le prime tre iterazioni e verifica i valori del contatore."
        }
    };

    GuideWindow window(sections);
    return window.run(L"Cicli C++ — while e for");
}

} // namespace cicli_while_for
#else
#include <iostream>
namespace cicli_while_for {
inline int mostra_guida() {
    std::cout << "Questa guida visuale richiede Windows." << std::endl;
    return 0;
}
}
#endif
