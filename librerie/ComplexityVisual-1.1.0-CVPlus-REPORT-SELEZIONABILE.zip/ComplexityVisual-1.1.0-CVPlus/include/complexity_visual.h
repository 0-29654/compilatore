#pragma once
#ifndef COMPLEXITY_VISUAL_CVPLUS_H
#define COMPLEXITY_VISUAL_CVPLUS_H

#include <string>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace complexity_visual {

enum EsempioComplessita {
    ESEMPIO_ACCESSO_ARRAY,
    ESEMPIO_ASSEGNAZIONE,
    ESEMPIO_CICLO_LINEARE,
    ESEMPIO_DUE_CICLI_CONSECUTIVI,
    ESEMPIO_DUE_CICLI_ANNIDATI,
    ESEMPIO_TRIANGOLO,
    ESEMPIO_TRE_CICLI,
    ESEMPIO_DIMEZZAMENTO,
    ESEMPIO_RADDOPPIO,
    ESEMPIO_N_LOG_N,
    ESEMPIO_RICERCA_LINEARE,
    ESEMPIO_RICERCA_BINARIA,
    ESEMPIO_BUBBLE_SORT,
    ESEMPIO_SELECTION_SORT,
    ESEMPIO_INSERTION_SORT,
    ESEMPIO_MERGE_SORT,
    ESEMPIO_QUICK_SORT,
    ESEMPIO_HEAP_SORT,
    ESEMPIO_FIBONACCI_RICORSIVO,
    ESEMPIO_FIBONACCI_DP,
    ESEMPIO_PERMUTAZIONI,
    ESEMPIO_PRIMALITA,
    ESEMPIO_MATRICE,
    ESEMPIO_HASH_TABLE,
    ESEMPIO_LISTA_COLLEGATA,
    ESEMPIO_ALBERO_BINARIO_BILANCIATO,
    ESEMPIO_ALBERO_DEGENERATO,
    ESEMPIO_BFS,
    ESEMPIO_DFS,
    ESEMPIO_DIJKSTRA,
    ESEMPIO_TERMINE_DOMINANTE
};

#ifdef _WIN32

struct Record {
    EsempioComplessita id;
    const wchar_t* title;
    const wchar_t* best;
    const wchar_t* average;
    const wchar_t* worst;
    const wchar_t* space;
    const wchar_t* code;
    const wchar_t* steps;
    const wchar_t* formula;
    const wchar_t* finalOrder;
};

class ComplexityWindow {
public:
    ComplexityWindow(EsempioComplessita selected, bool catalog)
        : selected_(selected), catalogMode_(catalog) {}

    int run() {
        instance_ = this;
        HINSTANCE inst = GetModuleHandleW(nullptr);
        WNDCLASSW wc{};
        wc.lpfnWndProc = &ComplexityWindow::WndProc;
        wc.hInstance = inst;
        wc.lpszClassName = L"CVPLUS_COMPLEXITY_REPORT_110";
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = CreateSolidBrush(RGB(15, 23, 42));
        RegisterClassW(&wc);

        hwnd_ = CreateWindowExW(
            WS_EX_APPWINDOW, wc.lpszClassName,
            L"Report visuale complessita' computazionale - Copyright Alessandro Barazzuol",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1350, 820,
            nullptr, nullptr, inst, nullptr
        );
        if (!hwnd_) return -1;

        ShowWindow(hwnd_, SW_MAXIMIZE);
        UpdateWindow(hwnd_);

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        instance_ = nullptr;
        return 0;
    }

private:
    static ComplexityWindow* instance_;

    static const std::vector<Record>& records() {
        static const std::vector<Record> r = {
        {ESEMPIO_ACCESSO_ARRAY, L"Accesso diretto a un elemento", L"O(1)", L"O(1)", L"O(1)", L"O(1)", L"int x = a[5];", L"1. L'indice 5 identifica direttamente una cella.\\r\\n2. Non si visitano gli altri elementi.\\r\\n3. Il numero di operazioni resta costante anche se n cresce.", L"T(n) = c", L"O(1)"},
        {ESEMPIO_ASSEGNAZIONE, L"Assegnazione e operazione semplice", L"O(1)", L"O(1)", L"O(1)", L"O(1)", L"x = y + 3;", L"1. Una somma costa un numero costante di operazioni.\\r\\n2. Anche l'assegnazione e' costante.\\r\\n3. La dimensione n non compare.", L"T(n) = c1 + c2", L"O(1)"},
        {ESEMPIO_CICLO_LINEARE, L"Ciclo lineare", L"O(n)", L"O(n)", L"O(n)", L"O(1)", L"for (int i = 0; i < n; i++)\n    somma += a[i];", L"1. Il ciclo esegue n iterazioni.\\r\\n2. Il corpo costa O(1).\\r\\n3. n * O(1) = O(n).", L"T(n) = c0 + n(c1+c2)", L"O(n)"},
        {ESEMPIO_DUE_CICLI_CONSECUTIVI, L"Due cicli consecutivi", L"O(n)", L"O(n)", L"O(n)", L"O(1)", L"for (int i=0;i<n;i++) ...;\nfor (int j=0;j<n;j++) ...;", L"1. Il primo ciclo costa O(n).\\r\\n2. Il secondo ciclo costa O(n).\\r\\n3. O(n)+O(n)=O(2n), le costanti si eliminano.", L"T(n) = n + n = 2n", L"O(n)"},
        {ESEMPIO_DUE_CICLI_ANNIDATI, L"Due cicli annidati", L"O(n^2)", L"O(n^2)", L"O(n^2)", L"O(1)", L"for (int i=0;i<n;i++)\n    for (int j=0;j<n;j++)\n        operazione();", L"1. Il ciclo esterno esegue n iterazioni.\\r\\n2. Per ogni iterazione, il ciclo interno ne esegue n.\\r\\n3. n * n = n^2.", L"T(n) = n * n", L"O(n^2)"},
        {ESEMPIO_TRIANGOLO, L"Ciclo triangolare", L"O(n^2)", L"O(n^2)", L"O(n^2)", L"O(1)", L"for (int i=0;i<n;i++)\n    for (int j=0;j<=i;j++)\n        operazione();", L"1. Il ciclo interno esegue 1,2,3,...,n iterazioni.\\r\\n2. La somma vale n(n+1)/2.\\r\\n3. Il termine dominante e' n^2.", L"T(n)=1+2+...+n=n(n+1)/2", L"O(n^2)"},
        {ESEMPIO_TRE_CICLI, L"Tre cicli annidati", L"O(n^3)", L"O(n^3)", L"O(n^3)", L"O(1)", L"for i in n\n  for j in n\n    for k in n", L"1. Tre cicli dipendenti da n sono annidati.\\r\\n2. Le complessita' si moltiplicano.\\r\\n3. n*n*n = n^3.", L"T(n)=n*n*n", L"O(n^3)"},
        {ESEMPIO_DIMEZZAMENTO, L"Ciclo con dimezzamento", L"O(log n)", L"O(log n)", L"O(log n)", L"O(1)", L"while (n > 1)\n    n /= 2;", L"1. A ogni iterazione n viene dimezzato.\\r\\n2. Dopo k passi: n/2^k = 1.\\r\\n3. Quindi k = log2(n).", L"n / 2^k = 1  =>  k = log2(n)", L"O(log n)"},
        {ESEMPIO_RADDOPPIO, L"Ciclo con raddoppio", L"O(log n)", L"O(log n)", L"O(log n)", L"O(1)", L"for (int i=1; i<n; i*=2)\n    operazione();", L"1. i assume 1,2,4,8,...\\r\\n2. Dopo k passi i=2^k.\\r\\n3. 2^k >= n, quindi k=log2(n).", L"2^k >= n", L"O(log n)"},
        {ESEMPIO_N_LOG_N, L"Ciclo lineare con ciclo logaritmico", L"O(n log n)", L"O(n log n)", L"O(n log n)", L"O(1)", L"for (int i=0;i<n;i++)\n    for (int j=n;j>1;j/=2)\n        operazione();", L"1. Il ciclo esterno costa n.\\r\\n2. Il ciclo interno costa log n.\\r\\n3. Essendo annidati: n * log n.", L"T(n)=n*log2(n)", L"O(n log n)"},
        {ESEMPIO_RICERCA_LINEARE, L"Ricerca lineare", L"O(1)", L"O(n)", L"O(n)", L"O(1)", L"for (int i=0;i<n;i++)\n    if (a[i]==x) return i;", L"1. Caso migliore: il valore e' al primo posto.\\r\\n2. Caso medio: si visita circa meta' array.\\r\\n3. Caso peggiore: si visitano tutti gli n elementi.", L"Tbest=1, Tavg≈n/2, Tworst=n", L"O(n)"},
        {ESEMPIO_RICERCA_BINARIA, L"Ricerca binaria", L"O(1)", L"O(log n)", L"O(log n)", L"O(1)", L"while (sinistra <= destra) {\n    centro=(sinistra+destra)/2;\n    ...\n}", L"1. L'array deve essere ordinato.\\r\\n2. A ogni confronto si elimina meta' dell'intervallo.\\r\\n3. Servono al massimo log2(n) confronti.", L"n / 2^k = 1", L"O(log n)"},
        {ESEMPIO_BUBBLE_SORT, L"Bubble Sort", L"O(n)", L"O(n^2)", L"O(n^2)", L"O(1)", L"for (int i=0;i<n-1;i++)\n  for (int j=0;j<n-i-1;j++)\n    if (a[j]>a[j+1]) swap(a[j],a[j+1]);", L"1. Due cicli annidati.\\r\\n2. I confronti sono circa n(n-1)/2.\\r\\n3. Con controllo scambi, array gia' ordinato: O(n).", L"T(n)=(n-1)+(n-2)+...+1", L"O(n^2)"},
        {ESEMPIO_SELECTION_SORT, L"Selection Sort", L"O(n^2)", L"O(n^2)", L"O(n^2)", L"O(1)", L"for (int i=0;i<n-1;i++) {\n  cerca il minimo da i a n;\n  swap(...);\n}", L"1. Per ogni posizione si cerca il minimo nella parte restante.\\r\\n2. I confronti sono n-1,n-2,...,1.\\r\\n3. La somma e' n(n-1)/2.", L"T(n)=sum(k=1..n-1) k", L"O(n^2)"},
        {ESEMPIO_INSERTION_SORT, L"Insertion Sort", L"O(n)", L"O(n^2)", L"O(n^2)", L"O(1)", L"for (int i=1;i<n;i++) {\n  chiave=a[i];\n  while (j>=0 && a[j]>chiave) ...;\n}", L"1. Array ordinato: un solo confronto per elemento.\\r\\n2. Caso medio e peggiore: molti spostamenti.\\r\\n3. Nel peggiore circa n(n-1)/2.", L"Tbest=n, Tworst=n(n-1)/2", L"O(n^2)"},
        {ESEMPIO_MERGE_SORT, L"Merge Sort", L"O(n log n)", L"O(n log n)", L"O(n log n)", L"O(n)", L"dividi l'array;\nordina le due meta';\nfondi le meta';", L"1. Ogni livello di ricorsione processa n elementi.\\r\\n2. I livelli sono log2(n).\\r\\n3. n elementi * log n livelli.", L"T(n)=2T(n/2)+n", L"O(n log n)"},
        {ESEMPIO_QUICK_SORT, L"Quick Sort", L"O(n log n)", L"O(n log n)", L"O(n^2)", L"O(log n) medio", L"scegli pivot;\npartiziona;\nquickSort(sinistra);\nquickSort(destra);", L"1. Partizioni equilibrate: log n livelli.\\r\\n2. Ogni livello costa n.\\r\\n3. Pivot sempre pessimo: n livelli, quindi n^2.", L"Tmedio=2T(n/2)+n; Tpeggiore=T(n-1)+n", L"O(n log n) medio"},
        {ESEMPIO_HEAP_SORT, L"Heap Sort", L"O(n log n)", L"O(n log n)", L"O(n log n)", L"O(1)", L"costruisci heap;\nripeti estrazione massimo;", L"1. Costruzione heap: O(n).\\r\\n2. n estrazioni, ciascuna O(log n).\\r\\n3. O(n)+O(n log n)=O(n log n).", L"T(n)=O(n)+n*O(log n)", L"O(n log n)"},
        {ESEMPIO_FIBONACCI_RICORSIVO, L"Fibonacci ricorsivo ingenuo", L"O(2^n)", L"O(2^n)", L"O(2^n)", L"O(n)", L"int fib(int n) {\n  if(n<=1) return n;\n  return fib(n-1)+fib(n-2);\n}", L"1. Ogni chiamata genera fino a due chiamate.\\r\\n2. Si forma un albero ricorsivo.\\r\\n3. Il numero di nodi cresce esponenzialmente.", L"T(n)=T(n-1)+T(n-2)+O(1)", L"O(2^n)"},
        {ESEMPIO_FIBONACCI_DP, L"Fibonacci con programmazione dinamica", L"O(n)", L"O(n)", L"O(n)", L"O(n)", L"dp[0]=0; dp[1]=1;\nfor (int i=2;i<=n;i++)\n  dp[i]=dp[i-1]+dp[i-2];", L"1. Si calcola ogni valore una sola volta.\\r\\n2. Il ciclo esegue n iterazioni.\\r\\n3. L'array dp occupa n celle.", L"T(n)=n", L"O(n)"},
        {ESEMPIO_PERMUTAZIONI, L"Generazione di tutte le permutazioni", L"O(n!)", L"O(n!)", L"O(n!)", L"O(n)", L"genera tutte le disposizioni possibili;", L"1. Ci sono n scelte per il primo posto.\\r\\n2. Poi n-1, poi n-2, ecc.\\r\\n3. Il prodotto e' n!.", L"n*(n-1)*(n-2)*...*1", L"O(n!)"},
        {ESEMPIO_PRIMALITA, L"Test di primalita' fino a radice di n", L"O(1)", L"O(sqrt(n))", L"O(sqrt(n))", L"O(1)", L"for (int i=2; i*i<=n; i++)\n    if (n%i==0) return false;", L"1. Basta provare i divisori fino a sqrt(n).\\r\\n2. Se n ha un fattore maggiore di sqrt(n), ne ha uno minore.\\r\\n3. Il ciclo esegue circa sqrt(n) tentativi.", L"i <= sqrt(n)", L"O(sqrt(n))"},
        {ESEMPIO_MATRICE, L"Visita di una matrice n x m", L"O(n*m)", L"O(n*m)", L"O(n*m)", L"O(1)", L"for (int i=0;i<n;i++)\n  for (int j=0;j<m;j++)\n    usa(matrice[i][j]);", L"1. Il ciclo esterno esegue n iterazioni.\\r\\n2. Il ciclo interno m iterazioni.\\r\\n3. Le dimensioni si moltiplicano: n*m.", L"T(n,m)=n*m", L"O(n*m)"},
        {ESEMPIO_HASH_TABLE, L"Accesso a hash table", L"O(1)", L"O(1)", L"O(n)", L"O(n)", L"unordered_map<string,int> m;\nint x = m[chiave];", L"1. Con buona distribuzione hash, accesso medio costante.\\r\\n2. Con molte collisioni, una catena puo' contenere n elementi.\\r\\n3. Quindi il peggiore e' O(n).", L"Tmedio=O(1), Tworst=O(n)", L"O(1) medio"},
        {ESEMPIO_LISTA_COLLEGATA, L"Ricerca in lista collegata", L"O(1)", L"O(n)", L"O(n)", L"O(1)", L"Nodo* p = testa;\nwhile (p && p->dato != x)\n    p = p->next;", L"1. Non esiste accesso diretto per indice.\\r\\n2. Si seguono i puntatori uno alla volta.\\r\\n3. Nel peggiore si visitano tutti i nodi.", L"T(n)=n", L"O(n)"},
        {ESEMPIO_ALBERO_BINARIO_BILANCIATO, L"Ricerca in albero binario bilanciato", L"O(1)", L"O(log n)", L"O(log n)", L"O(1)", L"if (x < nodo->dato) vai a sinistra;\nelse vai a destra;", L"1. Ogni confronto sceglie uno dei due sottoalberi.\\r\\n2. In un albero bilanciato l'altezza e' log n.\\r\\n3. Il costo segue l'altezza.", L"T(n)=T(n/2)+O(1)", L"O(log n)"},
        {ESEMPIO_ALBERO_DEGENERATO, L"Ricerca in albero degenerato", L"O(1)", L"O(n)", L"O(n)", L"O(1)", L"albero con nodi tutti dallo stesso lato;", L"1. L'albero si comporta come una lista.\\r\\n2. L'altezza diventa n.\\r\\n3. La ricerca puo' visitare tutti i nodi.", L"altezza = n", L"O(n)"},
        {ESEMPIO_BFS, L"BFS su grafo", L"O(V+E)", L"O(V+E)", L"O(V+E)", L"O(V)", L"queue<int> q;\nvisita ogni vertice e ogni arco;", L"1. Ogni vertice entra in coda al massimo una volta.\\r\\n2. Ogni arco viene esaminato al massimo una volta.\\r\\n3. Totale V+E.", L"T(V,E)=V+E", L"O(V+E)"},
        {ESEMPIO_DFS, L"DFS su grafo", L"O(V+E)", L"O(V+E)", L"O(V+E)", L"O(V)", L"dfs(v) {\n  visitato[v]=true;\n  per ogni vicino ...\n}", L"1. Ogni vertice viene visitato una volta.\\r\\n2. Ogni arco viene esaminato.\\r\\n3. Totale V+E.", L"T(V,E)=V+E", L"O(V+E)"},
        {ESEMPIO_DIJKSTRA, L"Dijkstra con coda di priorita'", L"O((V+E) log V)", L"O((V+E) log V)", L"O((V+E) log V)", L"O(V+E)", L"priority_queue<...> pq;\nrilassa gli archi;", L"1. Ogni estrazione/inserimento nella coda costa log V.\\r\\n2. Si gestiscono vertici e archi.\\r\\n3. Totale tipico (V+E)log V.", L"T(V,E)=(V+E)log V", L"O((V+E) log V)"},
        {ESEMPIO_TERMINE_DOMINANTE, L"Somma di blocchi con ordini diversi", L"O(n^2)", L"O(n^2)", L"O(n^2)", L"O(1)", L"blocco O(n);\nblocco O(n^2);\nblocco O(log n);", L"1. I blocchi consecutivi si sommano.\\r\\n2. O(n)+O(n^2)+O(log n).\\r\\n3. Domina n^2, quindi il risultato e' O(n^2).", L"T(n)=n+n^2+log n", L"O(n^2)"}
        };
        return r;
    }

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        if (!instance_) return DefWindowProcW(hwnd, msg, wp, lp);
        return instance_->handle(hwnd, msg, wp, lp);
    }

    LRESULT handle(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_CREATE:
            createControls(hwnd);
            return 0;
        case WM_SIZE:
            layout(LOWORD(lp), HIWORD(lp));
            return 0;
        case WM_COMMAND:
            if (LOWORD(wp) == 1001 && HIWORD(wp) == LBN_SELCHANGE) {
                int idx = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (idx >= 0) showRecord(idx);
                return 0;
            }
            if (LOWORD(wp) == 1002) {
                int idx = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (idx > 0) {
                    SendMessageW(list_, LB_SETCURSEL, idx - 1, 0);
                    showRecord(idx - 1);
                }
                return 0;
            }
            if (LOWORD(wp) == 1003) {
                int idx = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (idx + 1 < static_cast<int>(records().size())) {
                    SendMessageW(list_, LB_SETCURSEL, idx + 1, 0);
                    showRecord(idx + 1);
                }
                return 0;
            }
            if (LOWORD(wp) == 1004) {
                DestroyWindow(hwnd);
                return 0;
            }
            break;
        case WM_KEYDOWN:
            if (wp == VK_ESCAPE) DestroyWindow(hwnd);
            return 0;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    int indexOf(EsempioComplessita id) const {
        for (int i = 0; i < static_cast<int>(records().size()); ++i)
            if (records()[i].id == id) return i;
        return 0;
    }

    void createControls(HWND hwnd) {
        HINSTANCE inst = GetModuleHandleW(nullptr);
        title_ = CreateWindowW(
            L"STATIC", L"REPORT VISUALE DELLA COMPLESSITA' COMPUTAZIONALE",
            WS_CHILD | WS_VISIBLE,
            20, 16, 900, 38, hwnd, nullptr, inst, nullptr
        );

        list_ = CreateWindowW(
            L"LISTBOX", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY | WS_VSCROLL,
            20, 72, 360, 620, hwnd,
            reinterpret_cast<HMENU>(1001), inst, nullptr
        );

        report_ = CreateWindowW(
            L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_READONLY |
            ES_AUTOVSCROLL | WS_VSCROLL,
            405, 72, 850, 620, hwnd, nullptr, inst, nullptr
        );

        prev_ = CreateWindowW(
            L"BUTTON", L"PRECEDENTE",
            WS_CHILD | WS_VISIBLE,
            20, 710, 130, 42, hwnd,
            reinterpret_cast<HMENU>(1002), inst, nullptr
        );
        next_ = CreateWindowW(
            L"BUTTON", L"SUCCESSIVO",
            WS_CHILD | WS_VISIBLE,
            165, 710, 130, 42, hwnd,
            reinterpret_cast<HMENU>(1003), inst, nullptr
        );
        close_ = CreateWindowW(
            L"BUTTON", L"CHIUDI",
            WS_CHILD | WS_VISIBLE,
            1140, 710, 110, 42, hwnd,
            reinterpret_cast<HMENU>(1004), inst, nullptr
        );

        for (const auto& r : records())
            SendMessageW(list_, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(r.title));

        int idx = indexOf(selected_);
        SendMessageW(list_, LB_SETCURSEL, idx, 0);
        showRecord(idx);
    }

    void layout(int width, int height) {
        MoveWindow(title_, 20, 16, width - 40, 40, TRUE);
        MoveWindow(list_, 20, 72, 360, height - 165, TRUE);
        MoveWindow(report_, 405, 72, width - 430, height - 165, TRUE);
        MoveWindow(prev_, 20, height - 75, 130, 42, TRUE);
        MoveWindow(next_, 165, height - 75, 130, 42, TRUE);
        MoveWindow(close_, width - 130, height - 75, 110, 42, TRUE);
    }

    void showRecord(int idx) {
        if (idx < 0 || idx >= static_cast<int>(records().size())) return;
        const auto& r = records()[idx];

        std::wstring text;
        text += L"ESEMPIO " + std::to_wstring(idx + 1) + L" DI " +
                std::to_wstring(records().size()) + L"\r\n";
        text += L"============================================================\r\n\r\n";
        text += L"ALGORITMO / COSTRUTTO\r\n";
        text += r.title;
        text += L"\r\n\r\nCODICE DA STUDIARE\r\n";
        text += r.code;
        text += L"\r\n\r\nCASI DI COMPLESSITA'\r\n";
        text += L"  Migliore: " + std::wstring(r.best) + L"\r\n";
        text += L"  Medio:    " + std::wstring(r.average) + L"\r\n";
        text += L"  Peggiore: " + std::wstring(r.worst) + L"\r\n";
        text += L"  Spazio:   " + std::wstring(r.space) + L"\r\n";
        text += L"\r\nCALCOLO PASSO PER PASSO\r\n";
        text += r.steps;
        text += L"\r\n\r\nFORMULA / CONTEGGIO\r\n";
        text += r.formula;
        text += L"\r\n\r\nSEMPLIFICAZIONE BIG O\r\n";
        text += L"- Elimino le costanti moltiplicative.\r\n";
        text += L"- Elimino i termini di ordine inferiore.\r\n";
        text += L"- Mantengo il termine che cresce piu' velocemente.\r\n";
        text += L"\r\nRISULTATO FINALE\r\n";
        text += r.finalOrder;
        text += L"\r\n\r\nCopyright Alessandro Barazzuol";

        SetWindowTextW(report_, text.c_str());
    }

    EsempioComplessita selected_;
    bool catalogMode_ = false;
    HWND hwnd_ = nullptr;
    HWND title_ = nullptr;
    HWND list_ = nullptr;
    HWND report_ = nullptr;
    HWND prev_ = nullptr;
    HWND next_ = nullptr;
    HWND close_ = nullptr;
};

ComplexityWindow* ComplexityWindow::instance_ = nullptr;

inline int visualizzaComplessita(EsempioComplessita esempio) {
    ComplexityWindow w(esempio, false);
    return w.run();
}

inline int apriCatalogoComplessita() {
    ComplexityWindow w(ESEMPIO_ACCESSO_ARRAY, true);
    return w.run();
}

#else

inline int visualizzaComplessita(EsempioComplessita) { return 0; }
inline int apriCatalogoComplessita() { return 0; }

#endif

} // namespace complexity_visual

using complexity_visual::EsempioComplessita;
using complexity_visual::visualizzaComplessita;
using complexity_visual::apriCatalogoComplessita;
using complexity_visual::ESEMPIO_ACCESSO_ARRAY;
using complexity_visual::ESEMPIO_ASSEGNAZIONE;
using complexity_visual::ESEMPIO_CICLO_LINEARE;
using complexity_visual::ESEMPIO_DUE_CICLI_CONSECUTIVI;
using complexity_visual::ESEMPIO_DUE_CICLI_ANNIDATI;
using complexity_visual::ESEMPIO_TRIANGOLO;
using complexity_visual::ESEMPIO_TRE_CICLI;
using complexity_visual::ESEMPIO_DIMEZZAMENTO;
using complexity_visual::ESEMPIO_RADDOPPIO;
using complexity_visual::ESEMPIO_N_LOG_N;
using complexity_visual::ESEMPIO_RICERCA_LINEARE;
using complexity_visual::ESEMPIO_RICERCA_BINARIA;
using complexity_visual::ESEMPIO_BUBBLE_SORT;
using complexity_visual::ESEMPIO_SELECTION_SORT;
using complexity_visual::ESEMPIO_INSERTION_SORT;
using complexity_visual::ESEMPIO_MERGE_SORT;
using complexity_visual::ESEMPIO_QUICK_SORT;
using complexity_visual::ESEMPIO_HEAP_SORT;
using complexity_visual::ESEMPIO_FIBONACCI_RICORSIVO;
using complexity_visual::ESEMPIO_FIBONACCI_DP;
using complexity_visual::ESEMPIO_PERMUTAZIONI;
using complexity_visual::ESEMPIO_PRIMALITA;
using complexity_visual::ESEMPIO_MATRICE;
using complexity_visual::ESEMPIO_HASH_TABLE;
using complexity_visual::ESEMPIO_LISTA_COLLEGATA;
using complexity_visual::ESEMPIO_ALBERO_BINARIO_BILANCIATO;
using complexity_visual::ESEMPIO_ALBERO_DEGENERATO;
using complexity_visual::ESEMPIO_BFS;
using complexity_visual::ESEMPIO_DFS;
using complexity_visual::ESEMPIO_DIJKSTRA;
using complexity_visual::ESEMPIO_TERMINE_DOMINANTE;

#endif
