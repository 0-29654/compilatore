#pragma once
#ifndef COMPLEXITY_VISUAL_CVPLUS_H
#define COMPLEXITY_VISUAL_CVPLUS_H

#include <string>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace complexity_visual {

#ifdef _WIN32

struct Example {
    const wchar_t* title;
    const wchar_t* time;
    const wchar_t* space;
    const wchar_t* code;
    const wchar_t* explanation;
};

class Window {
public:
    int run() {
        instance_ = this;
        HINSTANCE inst = GetModuleHandleW(nullptr);

        WNDCLASSW wc{};
        wc.lpfnWndProc = &Window::WndProc;
        wc.hInstance = inst;
        wc.lpszClassName = L"CVPLUS_COMPLEXITY_VISUAL";
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = CreateSolidBrush(RGB(15, 23, 42));
        RegisterClassW(&wc);

        hwnd_ = CreateWindowExW(
            WS_EX_APPWINDOW,
            wc.lpszClassName,
            L"Complessita' Computazionale Visuale - Copyright Alessandro Barazzuol",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            CW_USEDEFAULT, CW_USEDEFAULT, 1300, 800,
            nullptr, nullptr, inst, nullptr
        );
        if (!hwnd_) return -1;

        ShowWindow(hwnd_, SW_MAXIMIZE);
        UpdateWindow(hwnd_);

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        instance_ = nullptr;
        return 0;
    }

private:
    static Window* instance_;

    static const std::vector<Example>& examples() {
        static const std::vector<Example> data = {
        {L"Accesso a un elemento", L"O(1)", L"O(1)", L"int x = a[5];", L"L'indice porta direttamente alla posizione desiderata. Il numero di operazioni non dipende da n."},
        {L"Assegnazione e operazioni semplici", L"O(1)", L"O(1)", L"x = y + 3;", L"Somma e assegnazione richiedono un numero costante di operazioni."},
        {L"Ciclo lineare", L"O(n)", L"O(1)", L"for (int i=0; i<n; i++) somma += a[i];", L"Il corpo viene eseguito n volte. Costante per iterazione moltiplicata per n."},
        {L"Due cicli consecutivi", L"O(n)", L"O(1)", L"for (...) {...}\nfor (...) {...}", L"Le complessita' consecutive si sommano: O(n)+O(n)=O(2n), che si semplifica in O(n)."},
        {L"Due cicli annidati", L"O(n^2)", L"O(1)", L"for (int i=0;i<n;i++)\n  for (int j=0;j<n;j++) ...;", L"Il ciclo interno viene eseguito n volte per ognuna delle n iterazioni esterne: n*n."},
        {L"Tre cicli annidati", L"O(n^3)", L"O(1)", L"for i\n  for j\n    for k", L"Tre dipendenze da n annidate si moltiplicano: n*n*n."},
        {L"Ciclo dimezzato", L"O(log n)", L"O(1)", L"while (n > 1) n /= 2;", L"A ogni passaggio il problema si dimezza. Il numero di dimezzamenti e' log2(n)."},
        {L"Ciclo che raddoppia", L"O(log n)", L"O(1)", L"for (int i=1; i<n; i*=2) ...;", L"i assume 1,2,4,8,... fino a n: servono circa log2(n) iterazioni."},
        {L"Ciclo lineare con dimezzamento interno", L"O(n log n)", L"O(1)", L"for (int i=0;i<n;i++)\n  for (int j=n;j>1;j/=2) ...;", L"Il ciclo esterno costa n; quello interno log n. Essendo annidati si moltiplicano."},
        {L"Ricerca lineare", L"O(n)", L"O(1)", L"for (...) if (a[i] == x) return i;", L"Nel caso peggiore si controllano tutti gli elementi. Caso migliore O(1), medio e peggiore O(n)."},
        {L"Ricerca binaria", L"O(log n)", L"O(1)", L"while (sinistra <= destra) { ... }", L"Richiede array ordinato. A ogni confronto elimina meta' degli elementi."},
        {L"Bubble sort", L"O(n^2)", L"O(1)", L"for i\n  for j\n    if (a[j] > a[j+1]) swap(...);", L"Due cicli annidati. Con ottimizzazione: migliore O(n), medio e peggiore O(n^2)."},
        {L"Selection sort", L"O(n^2)", L"O(1)", L"for i\n  cerca minimo da i a n\n  swap", L"Per ogni posizione cerca il minimo nella parte restante: circa n+(n-1)+...+1 confronti."},
        {L"Insertion sort", L"O(n^2)", L"O(1)", L"for i\n  while (j>=0 && a[j] > chiave) ...;", L"Migliore O(n) su array gia' ordinato; medio e peggiore O(n^2)."},
        {L"Merge sort", L"O(n log n)", L"O(n)", L"dividi; ordina meta'; fondi;", L"Ci sono log n livelli di divisione e ogni livello processa complessivamente n elementi."},
        {L"Quick sort", L"medio O(n log n), peggiore O(n^2)", L"O(log n) medio", L"scegli pivot; partiziona; ricorri;", L"Partizioni equilibrate producono log n livelli. Pivot pessimi possono creare n livelli."},
        {L"Fibonacci ricorsivo ingenuo", L"O(2^n)", L"O(n)", L"fib(n)=fib(n-1)+fib(n-2);", L"Ogni chiamata genera altre due chiamate. L'albero ricorsivo cresce esponenzialmente."},
        {L"Permutazioni", L"O(n!)", L"O(n)", L"genera tutte le permutazioni di n elementi;", L"Le permutazioni possibili sono n!. E' una crescita estremamente rapida."},
        {L"Ciclo fino a radice di n", L"O(sqrt(n))", L"O(1)", L"for (int i=2; i*i<=n; i++) ...;", L"i arriva circa a radice quadrata di n. Tipico nel test di primalita'."},
        {L"Matrice n x m", L"O(n*m)", L"O(1)", L"for (i=0;i<n;i++)\n  for (j=0;j<m;j++) ...;", L"Le due dimensioni possono essere diverse: n iterazioni per m iterazioni."},
        {L"Somma di blocchi diversi", L"O(n^2)", L"O(1)", L"blocco O(n) seguito da blocco O(n^2)", L"Per blocchi consecutivi domina il termine di ordine maggiore: O(n)+O(n^2)=O(n^2)."},
        {L"Hash table", L"medio O(1), peggiore O(n)", L"O(n)", L"unordered_map[key]", L"Con una buona funzione hash l'accesso medio e' costante; molte collisioni possono degradare a lineare."}
        };
        return data;
    }

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        if (!instance_) return DefWindowProcW(hwnd, msg, wp, lp);
        return instance_->handle(hwnd, msg, wp, lp);
    }

    LRESULT handle(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_CREATE:
            createControls(hwnd);
            return 0;
        case WM_SIZE:
            layout(LOWORD(lp), HIWORD(lp));
            return 0;
        case WM_COMMAND:
            if (LOWORD(wp) == 1001 && HIWORD(wp) == LBN_SELCHANGE) {
                int sel = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (sel >= 0) showExample(sel);
                return 0;
            }
            if (LOWORD(wp) == 1002) {
                int sel = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (sel > 0) {
                    SendMessageW(list_, LB_SETCURSEL, sel - 1, 0);
                    showExample(sel - 1);
                }
                return 0;
            }
            if (LOWORD(wp) == 1003) {
                int sel = static_cast<int>(SendMessageW(list_, LB_GETCURSEL, 0, 0));
                if (sel + 1 < static_cast<int>(examples().size())) {
                    SendMessageW(list_, LB_SETCURSEL, sel + 1, 0);
                    showExample(sel + 1);
                }
                return 0;
            }
            if (LOWORD(wp) == 1004) {
                DestroyWindow(hwnd);
                return 0;
            }
            break;
        case WM_KEYDOWN:
            if (wp == VK_ESCAPE) DestroyWindow(hwnd);
            return 0;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    void createControls(HWND hwnd) {
        HINSTANCE inst = GetModuleHandleW(nullptr);

        title_ = CreateWindowW(
            L"STATIC", L"COMPLESSITA' COMPUTAZIONALE VISUALE",
            WS_CHILD | WS_VISIBLE,
            20, 18, 600, 34, hwnd, nullptr, inst, nullptr
        );

        list_ = CreateWindowW(
            L"LISTBOX", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY | WS_VSCROLL,
            20, 72, 340, 600, hwnd,
            reinterpret_cast<HMENU>(1001), inst, nullptr
        );

        detail_ = CreateWindowW(
            L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_READONLY |
            ES_AUTOVSCROLL | WS_VSCROLL,
            385, 72, 820, 600, hwnd, nullptr, inst, nullptr
        );

        prev_ = CreateWindowW(
            L"BUTTON", L"PRECEDENTE",
            WS_CHILD | WS_VISIBLE,
            20, 690, 130, 42, hwnd,
            reinterpret_cast<HMENU>(1002), inst, nullptr
        );

        next_ = CreateWindowW(
            L"BUTTON", L"SUCCESSIVO",
            WS_CHILD | WS_VISIBLE,
            165, 690, 130, 42, hwnd,
            reinterpret_cast<HMENU>(1003), inst, nullptr
        );

        close_ = CreateWindowW(
            L"BUTTON", L"CHIUDI",
            WS_CHILD | WS_VISIBLE,
            1090, 690, 110, 42, hwnd,
            reinterpret_cast<HMENU>(1004), inst, nullptr
        );

        for (const auto& ex : examples()) {
            SendMessageW(list_, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(ex.title));
        }

        SendMessageW(list_, LB_SETCURSEL, 0, 0);
        showExample(0);
    }

    void layout(int width, int height) {
        MoveWindow(title_, 20, 18, width - 40, 38, TRUE);
        MoveWindow(list_, 20, 72, 340, height - 160, TRUE);
        MoveWindow(detail_, 385, 72, width - 410, height - 160, TRUE);
        MoveWindow(prev_, 20, height - 72, 130, 42, TRUE);
        MoveWindow(next_, 165, height - 72, 130, 42, TRUE);
        MoveWindow(close_, width - 130, height - 72, 110, 42, TRUE);
    }

    void showExample(int index) {
        if (index < 0 || index >= static_cast<int>(examples().size())) return;
        const auto& ex = examples()[index];

        std::wstring text;
        text += L"ESEMPIO " + std::to_wstring(index + 1) + L" DI " +
                std::to_wstring(examples().size()) + L"\r\n\r\n";
        text += L"ALGORITMO / STRUTTURA\r\n";
        text += ex.title;
        text += L"\r\n\r\nCOMPLESSITA' TEMPORALE\r\n";
        text += ex.time;
        text += L"\r\n\r\nCOMPLESSITA' SPAZIALE\r\n";
        text += ex.space;
        text += L"\r\n\r\nCODICE / SCHEMA\r\n";
        text += ex.code;
        text += L"\r\n\r\nCOME SI CALCOLA\r\n";
        text += ex.explanation;
        text += L"\r\n\r\nREGOLA DIDATTICA\r\n";
        text += L"- Blocchi consecutivi: si sommano e resta il termine dominante.\r\n";
        text += L"- Cicli annidati: si moltiplicano.\r\n";
        text += L"- Divisione del problema: spesso compare log n.\r\n";
        text += L"- Si eliminano costanti e termini di ordine inferiore.";

        SetWindowTextW(detail_, text.c_str());
    }

    HWND hwnd_ = nullptr;
    HWND title_ = nullptr;
    HWND list_ = nullptr;
    HWND detail_ = nullptr;
    HWND prev_ = nullptr;
    HWND next_ = nullptr;
    HWND close_ = nullptr;
};

Window* Window::instance_ = nullptr;

inline int apriComplessitaVisuale() {
    Window w;
    return w.run();
}

inline int visualizzaComplessita() {
    return apriComplessitaVisuale();
}

#else

inline int apriComplessitaVisuale() { return 0; }
inline int visualizzaComplessita() { return 0; }

#endif

} // namespace complexity_visual

using complexity_visual::apriComplessitaVisuale;
using complexity_visual::visualizzaComplessita;

#endif
