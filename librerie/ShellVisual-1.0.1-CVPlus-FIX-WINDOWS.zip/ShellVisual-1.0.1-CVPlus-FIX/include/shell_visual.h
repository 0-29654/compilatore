#pragma once
#ifndef SHELL_VISUAL_H
#define SHELL_VISUAL_H

#if !defined(_WIN32)
#error "ShellVisual funziona su Windows."
#endif

#include <windows.h>
#include <commctrl.h>
#include <streambuf>
#include <string>
#include <deque>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <atomic>
#include <algorithm>
#include <cstdlib>

namespace shellvisual_detail {

constexpr UINT WM_SV_APPEND = WM_APP + 101;
constexpr UINT WM_SV_READY  = WM_APP + 102;
constexpr int IDC_OUTPUT = 2001;
constexpr int IDC_INPUT  = 2002;
constexpr int IDC_CLEAR  = 2003;
constexpr int IDC_COPY   = 2004;
constexpr int IDC_EXIT   = 2005;

class ShellVisual;
inline ShellVisual* g_shell = nullptr;
inline WNDPROC g_oldInputProc = nullptr;

class OutputBuffer final : public std::streambuf {
public:
    explicit OutputBuffer(ShellVisual* owner) : owner_(owner) { setp(buffer_, buffer_ + sizeof(buffer_) - 1); }
    ~OutputBuffer() override { sync(); }
protected:
    int overflow(int ch) override;
    int sync() override;
private:
    bool flushBuffer();
    ShellVisual* owner_;
    char buffer_[512]{};
};

class InputBuffer final : public std::streambuf {
public:
    explicit InputBuffer(ShellVisual* owner) : owner_(owner) { setg(&current_, &current_ + 1, &current_ + 1); }
protected:
    int_type underflow() override;
private:
    ShellVisual* owner_;
    char current_ = 0;
};

class ShellVisual {
public:
    ShellVisual() : out_(this), in_(this) {
        g_shell = this;
        guiThread_ = std::thread([this] { guiMain(); });
        {
            std::unique_lock<std::mutex> lock(readyMutex_);
            readyCv_.wait(lock, [this] { return ready_.load(); });
        }
        oldOut_ = std::cout.rdbuf(&out_);
        oldErr_ = std::cerr.rdbuf(&out_);
        oldLog_ = std::clog.rdbuf(&out_);
        oldIn_  = std::cin.rdbuf(&in_);
        HWND console = GetConsoleWindow();
        if (console) ShowWindow(console, SW_HIDE);
    }

    ~ShellVisual() {
        std::cout.flush();
        std::cerr.flush();
        std::cout.rdbuf(oldOut_);
        std::cerr.rdbuf(oldErr_);
        std::clog.rdbuf(oldLog_);
        std::cin.rdbuf(oldIn_);
        if (hwnd_) PostMessageW(hwnd_, WM_CLOSE, 0, 0);
        if (guiThread_.joinable() && guiThread_.get_id() != std::this_thread::get_id()) guiThread_.join();
    }

    void append(const std::string& text) {
        if (text.empty()) return;
        HWND target = hwnd_;
        if (!target) return;
        auto* heapText = new std::string(text);
        if (!PostMessageW(target, WM_SV_APPEND, 0, reinterpret_cast<LPARAM>(heapText))) delete heapText;
    }

    void pushInput(const std::string& line) {
        {
            std::lock_guard<std::mutex> lock(inputMutex_);
            for (char c : line) inputQueue_.push_back(c);
            inputQueue_.push_back('\n');
        }
        inputCv_.notify_all();
    }

    int readChar() {
        std::unique_lock<std::mutex> lock(inputMutex_);
        inputCv_.wait(lock, [this] { return !inputQueue_.empty() || closing_.load(); });
        if (inputQueue_.empty()) return EOF;
        unsigned char c = static_cast<unsigned char>(inputQueue_.front());
        inputQueue_.pop_front();
        return c;
    }

private:
    friend class OutputBuffer;
    friend class InputBuffer;

    static std::wstring utf8ToWide(const std::string& s) {
        if (s.empty()) return {};
        int count = MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
        if (count <= 0) {
            count = MultiByteToWideChar(CP_ACP, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
            std::wstring w(static_cast<size_t>(std::max(count, 0)), L'\0');
            if (count > 0) MultiByteToWideChar(CP_ACP, 0, s.data(), static_cast<int>(s.size()), w.data(), count);
            return w;
        }
        std::wstring w(static_cast<size_t>(count), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), w.data(), count);
        return w;
    }

    static void setFont(HWND h, HFONT font) { SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE); }

    void appendWide(const std::wstring& text) {
        if (!output_ || text.empty()) return;
        int len = GetWindowTextLengthW(output_);
        constexpr int MAX_CHARS = 220000;
        if (len > MAX_CHARS) {
            SendMessageW(output_, EM_SETSEL, 0, len - 160000);
            SendMessageW(output_, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(L"[... output precedente ridotto ...]\r\n"));
            len = GetWindowTextLengthW(output_);
        }
        SendMessageW(output_, EM_SETSEL, len, len);
        std::wstring normalized;
        normalized.reserve(text.size() + 16);
        for (wchar_t c : text) {
            if (c == L'\n' && (normalized.empty() || normalized.back() != L'\r')) normalized.push_back(L'\r');
            normalized.push_back(c);
        }
        SendMessageW(output_, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(normalized.c_str()));
        SendMessageW(output_, EM_SCROLLCARET, 0, 0);
    }

    static LRESULT CALLBACK InputProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
        if (msg == WM_KEYDOWN && wp == VK_RETURN && g_shell) {
            int len = GetWindowTextLengthW(h);
            std::wstring w(static_cast<size_t>(len) + 1, L'\0');
            if (len > 0) GetWindowTextW(h, w.data(), len + 1);
            w.resize(static_cast<size_t>(len));
            int bytes = WideCharToMultiByte(CP_UTF8, 0, w.data(), len, nullptr, 0, nullptr, nullptr);
            std::string s(static_cast<size_t>(std::max(bytes, 0)), '\0');
            if (bytes > 0) WideCharToMultiByte(CP_UTF8, 0, w.data(), len, s.data(), bytes, nullptr, nullptr);
            g_shell->append(std::string("\n> ") + s + "\n");
            g_shell->pushInput(s);
            SetWindowTextW(h, L"");
            return 0;
        }
        return CallWindowProcW(g_oldInputProc, h, msg, wp, lp);
    }

    static LRESULT CALLBACK WindowProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
        ShellVisual* self = reinterpret_cast<ShellVisual*>(GetWindowLongPtrW(h, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
            self = static_cast<ShellVisual*>(cs->lpCreateParams);
            SetWindowLongPtrW(h, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        }
        if (!self) return DefWindowProcW(h, msg, wp, lp);

        switch (msg) {
        case WM_SIZE: {
            int w = LOWORD(lp), he = HIWORD(lp);
            int footer = 72;
            MoveWindow(self->output_, 16, 58, std::max(100, w - 32), std::max(80, he - footer - 58), TRUE);
            MoveWindow(self->input_, 16, he - 55, std::max(100, w - 330), 34, TRUE);
            MoveWindow(self->clearBtn_, w - 302, he - 55, 86, 34, TRUE);
            MoveWindow(self->copyBtn_,  w - 208, he - 55, 86, 34, TRUE);
            MoveWindow(self->exitBtn_,  w - 114, he - 55, 98, 34, TRUE);
            return 0;
        }
        case WM_COMMAND:
            switch (LOWORD(wp)) {
            case IDC_CLEAR: SetWindowTextW(self->output_, L""); return 0;
            case IDC_COPY:
                SendMessageW(self->output_, EM_SETSEL, 0, -1);
                SendMessageW(self->output_, WM_COPY, 0, 0);
                SendMessageW(self->output_, EM_SETSEL, -1, -1);
                return 0;
            case IDC_EXIT: DestroyWindow(h); return 0;
            }
            break;
        case WM_SV_APPEND: {
            auto* s = reinterpret_cast<std::string*>(lp);
            if (s) { self->appendWide(utf8ToWide(*s)); delete s; }
            return 0;
        }
        case WM_CTLCOLORSTATIC:
        case WM_CTLCOLOREDIT: {
            HDC dc = reinterpret_cast<HDC>(wp);
            SetTextColor(dc, RGB(226, 232, 240));
            SetBkColor(dc, RGB(15, 23, 42));
            return reinterpret_cast<LRESULT>(self->darkBrush_);
        }
        case WM_ERASEBKGND: {
            RECT rc; GetClientRect(h, &rc);
            FillRect(reinterpret_cast<HDC>(wp), &rc, self->backgroundBrush_);
            return 1;
        }
        case WM_PAINT: {
            PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps);
            RECT rc; GetClientRect(h, &rc);
            SetBkMode(dc, TRANSPARENT);
            SetTextColor(dc, RGB(56, 189, 248));
            HFONT old = reinterpret_cast<HFONT>(SelectObject(dc, self->titleFont_));
            TextOutW(dc, 16, 14, L"SHELL VISUAL C++", 16);
            SelectObject(dc, self->smallFont_);
            SetTextColor(dc, RGB(148, 163, 184));
            const wchar_t* sub = L"Console personalizzata - Copyright Alessandro Barazzuol";
            TextOutW(dc, 220, 20, sub, lstrlenW(sub));
            SelectObject(dc, old);
            EndPaint(h, &ps);
            return 0;
        }
        case WM_CLOSE: DestroyWindow(h); return 0;
        case WM_DESTROY:
            self->closing_.store(true);
            self->inputCv_.notify_all();
            PostQuitMessage(0);
            // Chiudere la shell termina anche un eventuale while(1), evitando processi invisibili.
            ExitProcess(0);
            return 0;
        }
        return DefWindowProcW(h, msg, wp, lp);
    }

    void guiMain() {
        INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_STANDARD_CLASSES};
        InitCommonControlsEx(&icc);
        HINSTANCE instance = GetModuleHandleW(nullptr);
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = WindowProc;
        wc.hInstance = instance;
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = nullptr;
        wc.lpszClassName = L"CVPlusShellVisualWindow";
        RegisterClassExW(&wc);

        backgroundBrush_ = CreateSolidBrush(RGB(2, 6, 23));
        darkBrush_ = CreateSolidBrush(RGB(15, 23, 42));
        titleFont_ = CreateFontW(-22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                 CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        smallFont_ = CreateFontW(-14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                 CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        monoFont_ = CreateFontW(-18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, L"Cascadia Mono");

        hwnd_ = CreateWindowExW(WS_EX_APPWINDOW, wc.lpszClassName, L"Shell Visual C++ - CV+", WS_OVERLAPPEDWINDOW,
                                CW_USEDEFAULT, CW_USEDEFAULT, 980, 680, nullptr, nullptr, instance, this);
        output_ = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY |
                                  ES_AUTOVSCROLL | WS_VSCROLL, 0, 0, 0, 0, hwnd_, reinterpret_cast<HMENU>(IDC_OUTPUT), instance, nullptr);
        input_ = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                                 0, 0, 0, 0, hwnd_, reinterpret_cast<HMENU>(IDC_INPUT), instance, nullptr);
        clearBtn_ = CreateWindowW(L"BUTTON", L"PULISCI", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0,0,0,0, hwnd_, reinterpret_cast<HMENU>(IDC_CLEAR), instance, nullptr);
        copyBtn_  = CreateWindowW(L"BUTTON", L"COPIA", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0,0,0,0, hwnd_, reinterpret_cast<HMENU>(IDC_COPY), instance, nullptr);
        exitBtn_  = CreateWindowW(L"BUTTON", L"ESCI", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0,0,0,0, hwnd_, reinterpret_cast<HMENU>(IDC_EXIT), instance, nullptr);

        setFont(output_, monoFont_); setFont(input_, monoFont_);
        setFont(clearBtn_, smallFont_); setFont(copyBtn_, smallFont_); setFont(exitBtn_, smallFont_);
        SendMessageW(output_, EM_SETLIMITTEXT, 300000, 0);
        SendMessageW(input_, EM_SETCUEBANNER, TRUE, reinterpret_cast<LPARAM>(L"Scrivi qui e premi INVIO..."));
        g_oldInputProc = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(input_, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(InputProc)));

        ShowWindow(hwnd_, SW_MAXIMIZE);
        UpdateWindow(hwnd_);
        SetFocus(input_);
        appendWide(L"Shell pronta. Usa normalmente cout e cin.\r\n\r\n");
        ready_.store(true);
        readyCv_.notify_all();

        MSG msg;
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }

        DeleteObject(monoFont_); DeleteObject(titleFont_); DeleteObject(smallFont_);
        DeleteObject(darkBrush_); DeleteObject(backgroundBrush_);
    }

    HWND hwnd_ = nullptr, output_ = nullptr, input_ = nullptr;
    HWND clearBtn_ = nullptr, copyBtn_ = nullptr, exitBtn_ = nullptr;
    HBRUSH backgroundBrush_ = nullptr, darkBrush_ = nullptr;
    HFONT monoFont_ = nullptr, titleFont_ = nullptr, smallFont_ = nullptr;
    std::thread guiThread_;
    std::atomic<bool> ready_{false}, closing_{false};
    std::mutex readyMutex_, inputMutex_;
    std::condition_variable readyCv_, inputCv_;
    std::deque<char> inputQueue_;
    OutputBuffer out_;
    InputBuffer in_;
    std::streambuf *oldOut_ = nullptr, *oldErr_ = nullptr, *oldLog_ = nullptr, *oldIn_ = nullptr;
};

inline bool OutputBuffer::flushBuffer() {
    const auto count = pptr() - pbase();
    if (count > 0 && owner_) owner_->append(std::string(pbase(), static_cast<size_t>(count)));
    setp(buffer_, buffer_ + sizeof(buffer_) - 1);
    return true;
}
inline int OutputBuffer::overflow(int ch) {
    flushBuffer();
    if (ch != traits_type::eof()) {
        *pptr() = static_cast<char>(ch);
        pbump(1);
        if (ch == '\n') flushBuffer();
    }
    return ch;
}
inline int OutputBuffer::sync() { return flushBuffer() ? 0 : -1; }
inline InputBuffer::int_type InputBuffer::underflow() {
    int c = owner_ ? owner_->readChar() : EOF;
    if (c == EOF) return traits_type::eof();
    current_ = static_cast<char>(c);
    setg(&current_, &current_, &current_ + 1);
    return traits_type::to_int_type(current_);
}

// Variabile inline: una sola istanza anche se l'header compare in più file C++17.
inline ShellVisual shellVisualInstance;

} // namespace shellvisual_detail

#endif
