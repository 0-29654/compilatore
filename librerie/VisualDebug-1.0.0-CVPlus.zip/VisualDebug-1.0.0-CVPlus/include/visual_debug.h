#pragma once
#ifndef VISUAL_DEBUG_CVPLUS_H
#define VISUAL_DEBUG_CVPLUS_H

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <exception>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <type_traits>
#include <vector>
#include <iostream>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <commctrl.h>
#endif

namespace visual_debug {

struct Event {
    std::string time;
    std::string type;
    std::string name;
    std::string value;
    std::string file;
    int line = 0;
};

class Debugger {
public:
    static Debugger& instance() {
        static Debugger d;
        return d;
    }

    void start(const std::string& title = "Visual Debug C++") {
        title_ = title;
#ifdef _WIN32
        bool expected = false;
        if (started_.compare_exchange_strong(expected, true)) {
            guiThread_ = std::thread([this] { guiMain(); });
            guiThread_.detach();
            while (!windowReady_.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
#else
        started_ = true;
#endif
        add("AVVIO", "programma", "Debug visuale avviato", __FILE__, __LINE__);
    }

    void add(const std::string& type, const std::string& name,
             const std::string& value, const char* file, int line) {
        if (!started_.load()) start();
        Event e{now(), type, name, value, shortFile(file), line};
        {
            std::lock_guard<std::mutex> lock(eventsMutex_);
            events_.push_back(e);
            if (events_.size() > 10000) events_.erase(events_.begin(), events_.begin() + 1000);
        }
#ifdef _WIN32
        if (hwnd_) PostMessageW(hwnd_, WM_APP + 1, 0, 0);
#else
        std::cerr << "[" << e.type << "] " << e.name << " = " << e.value
                  << " (" << e.file << ":" << e.line << ")\n";
#endif
    }

    void checkpoint(const std::string& label, const char* file, int line) {
        add("PASSO", label, "Punto di arresto", file, line);
        std::unique_lock<std::mutex> lock(stepMutex_);
        paused_ = true;
#ifdef _WIN32
        if (hwnd_) PostMessageW(hwnd_, WM_APP + 2, 0, 0);
#endif
        stepCv_.wait(lock, [this] { return !paused_ || closing_.load(); });
    }

    void resume() {
        {
            std::lock_guard<std::mutex> lock(stepMutex_);
            paused_ = false;
        }
        stepCv_.notify_all();
    }

    void finish() {
        add("FINE", "programma", "Programma terminato. La finestra resta aperta.", __FILE__, __LINE__);
    }

    template <typename F>
    int runGuarded(F&& fn) {
        try {
            fn();
            finish();
            return 0;
        } catch (const std::exception& ex) {
            add("ECCEZIONE", "std::exception", ex.what(), __FILE__, __LINE__);
            finish();
            return 1;
        } catch (...) {
            add("ECCEZIONE", "sconosciuta", "Errore runtime non riconosciuto", __FILE__, __LINE__);
            finish();
            return 2;
        }
    }

    template <typename T>
    static std::string toString(const T& value) {
        if constexpr (std::is_same_v<std::decay_t<T>, bool>) {
            return value ? "true" : "false";
        } else {
            std::ostringstream out;
            out << value;
            return out.str();
        }
    }

private:
    Debugger() = default;
    ~Debugger() {
        closing_ = true;
        resume();
    }
    Debugger(const Debugger&) = delete;
    Debugger& operator=(const Debugger&) = delete;

    std::string now() const {
        using namespace std::chrono;
        auto t = system_clock::to_time_t(system_clock::now());
        std::tm tm{};
#ifdef _WIN32
        localtime_s(&tm, &t);
#else
        localtime_r(&t, &tm);
#endif
        auto ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch()) % 1000;
        std::ostringstream out;
        out << std::put_time(&tm, "%H:%M:%S") << "."
            << std::setw(3) << std::setfill('0') << ms.count();
        return out.str();
    }

    static std::string shortFile(const char* file) {
        std::string s = file ? file : "";
        auto p = s.find_last_of("/\\");
        return p == std::string::npos ? s : s.substr(p + 1);
    }

#ifdef _WIN32
    static std::wstring widen(const std::string& s) {
        if (s.empty()) return L"";
        int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        std::wstring w(n ? n - 1 : 0, L'\0');
        if (n > 1) MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, w.data(), n);
        return w;
    }

    void insertEvent(const Event& e) {
        if (!list_) return;
        LVITEMW item{};
        item.mask = LVIF_TEXT;
        int row = ListView_GetItemCount(list_);
        std::wstring t = widen(e.time);
        item.iItem = row;
        item.pszText = t.data();
        ListView_InsertItem(list_, &item);

        auto setCol = [&](int col, const std::string& text) {
            std::wstring w = widen(text);
            ListView_SetItemText(list_, row, col, w.data());
        };
        setCol(1, e.type);
        setCol(2, e.name);
        setCol(3, e.value);
        setCol(4, e.file + ":" + std::to_string(e.line));
        ListView_EnsureVisible(list_, row, FALSE);
    }

    void flushEvents() {
        std::vector<Event> copy;
        {
            std::lock_guard<std::mutex> lock(eventsMutex_);
            if (shown_ >= events_.size()) return;
            copy.assign(events_.begin() + static_cast<long long>(shown_), events_.end());
            shown_ = events_.size();
        }
        for (const auto& e : copy) insertEvent(e);
    }

    static LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        Debugger* self = reinterpret_cast<Debugger*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            auto cs = reinterpret_cast<CREATESTRUCTW*>(lp);
            self = reinterpret_cast<Debugger*>(cs->lpCreateParams);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        }
        if (!self) return DefWindowProcW(hwnd, msg, wp, lp);

        switch (msg) {
        case WM_CREATE:
            return 0;
        case WM_SIZE: {
            int w = LOWORD(lp), h = HIWORD(lp);
            MoveWindow(self->list_, 16, 72, w - 32, h - 132, TRUE);
            MoveWindow(self->status_, 16, h - 48, w - 32, 28, TRUE);
            return 0;
        }
        case WM_COMMAND:
            switch (LOWORD(wp)) {
            case 1001: self->resume(); SetWindowTextW(self->status_, L"Esecuzione continua"); break;
            case 1002: self->resume(); SetWindowTextW(self->status_, L"Eseguito un passo"); break;
            case 1003:
                ListView_DeleteAllItems(self->list_);
                { std::lock_guard<std::mutex> lock(self->eventsMutex_); self->events_.clear(); self->shown_ = 0; }
                break;
            case 1004:
                SendMessageW(hwnd, WM_CLOSE, 0, 0);
                break;
            }
            return 0;
        case WM_APP + 1:
            self->flushEvents();
            return 0;
        case WM_APP + 2:
            SetWindowTextW(self->status_, L"Programma in pausa su VDBG_BREAKPOINT - premi Continua");
            return 0;
        case WM_CLOSE:
            self->closing_ = true;
            self->resume();
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    void guiMain() {
        INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_LISTVIEW_CLASSES};
        InitCommonControlsEx(&icc);

        HINSTANCE inst = GetModuleHandleW(nullptr);
        const wchar_t* cls = L"CVPLUS_VISUAL_DEBUG_WINDOW";
        WNDCLASSW wc{};
        wc.lpfnWndProc = wndProc;
        wc.hInstance = inst;
        wc.lpszClassName = cls;
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hIcon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = CreateSolidBrush(RGB(20, 25, 34));
        RegisterClassW(&wc);

        std::wstring title = widen(title_ + " - Copyright Alessandro Barazzuol");
        hwnd_ = CreateWindowExW(WS_EX_APPWINDOW, cls, title.c_str(),
            WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
            1180, 720, nullptr, nullptr, inst, this);

        CreateWindowW(L"STATIC", L"VISUAL DEBUG C++",
            WS_CHILD | WS_VISIBLE, 18, 14, 250, 28, hwnd_, nullptr, inst, nullptr);
        CreateWindowW(L"BUTTON", L"Continua", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            290, 14, 110, 32, hwnd_, reinterpret_cast<HMENU>(1001), inst, nullptr);
        CreateWindowW(L"BUTTON", L"Passo", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            410, 14, 90, 32, hwnd_, reinterpret_cast<HMENU>(1002), inst, nullptr);
        CreateWindowW(L"BUTTON", L"Pulisci", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            510, 14, 90, 32, hwnd_, reinterpret_cast<HMENU>(1003), inst, nullptr);
        CreateWindowW(L"BUTTON", L"Chiudi", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            610, 14, 90, 32, hwnd_, reinterpret_cast<HMENU>(1004), inst, nullptr);

        list_ = CreateWindowW(WC_LISTVIEWW, L"",
            WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL,
            16, 72, 1120, 540, hwnd_, nullptr, inst, nullptr);
        ListView_SetExtendedListViewStyle(list_, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);

        const wchar_t* names[] = {L"Ora", L"Tipo", L"Variabile / evento", L"Valore", L"Posizione"};
        int widths[] = {100, 110, 220, 450, 220};
        for (int i = 0; i < 5; ++i) {
            LVCOLUMNW col{};
            col.mask = LVCF_TEXT | LVCF_WIDTH;
            col.pszText = const_cast<wchar_t*>(names[i]);
            col.cx = widths[i];
            ListView_InsertColumn(list_, i, &col);
        }

        status_ = CreateWindowW(L"STATIC",
            L"Pronto. Usa VDBG_VAR, VDBG_MSG e VDBG_BREAKPOINT nel codice.",
            WS_CHILD | WS_VISIBLE, 16, 620, 900, 28, hwnd_, nullptr, inst, nullptr);

        windowReady_ = true;
        flushEvents();

        MSG msg{};
        while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        hwnd_ = nullptr;
    }
#endif

    std::atomic<bool> started_{false};
    std::atomic<bool> windowReady_{false};
    std::atomic<bool> closing_{false};
    std::string title_ = "Visual Debug C++";
    std::vector<Event> events_;
    std::mutex eventsMutex_;
    size_t shown_ = 0;
    std::mutex stepMutex_;
    std::condition_variable stepCv_;
    bool paused_ = false;
    std::thread guiThread_;
#ifdef _WIN32
    HWND hwnd_ = nullptr;
    HWND list_ = nullptr;
    HWND status_ = nullptr;
#endif
};

} // namespace visual_debug

#define VDBG_START(titolo) ::visual_debug::Debugger::instance().start((titolo))
#define VDBG_VAR(x) ::visual_debug::Debugger::instance().add("VARIABILE", #x, ::visual_debug::Debugger::toString((x)), __FILE__, __LINE__)
#define VDBG_MSG(testo) ::visual_debug::Debugger::instance().add("MESSAGGIO", "", (testo), __FILE__, __LINE__)
#define VDBG_ERROR(testo) ::visual_debug::Debugger::instance().add("ERRORE", "", (testo), __FILE__, __LINE__)
#define VDBG_STEP(nome) ::visual_debug::Debugger::instance().add("PASSO", (nome), "eseguito", __FILE__, __LINE__)
#define VDBG_BREAKPOINT(nome) ::visual_debug::Debugger::instance().checkpoint((nome), __FILE__, __LINE__)
#define VDBG_ASSERT(condizione) do { if (!(condizione)) { ::visual_debug::Debugger::instance().add("ASSERT", #condizione, "condizione falsa", __FILE__, __LINE__); } } while (0)
#define VDBG_FINISH() ::visual_debug::Debugger::instance().finish()
#define VDBG_RUN(codice) return ::visual_debug::Debugger::instance().runGuarded([&](){ codice; })

#endif
