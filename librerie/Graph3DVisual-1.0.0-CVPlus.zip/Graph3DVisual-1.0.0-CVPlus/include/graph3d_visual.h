#pragma once
#ifndef GRAPH3D_VISUAL_H
#define GRAPH3D_VISUAL_H
#include <cmath>
#include <functional>
#include <limits>
#include <string>
#include <vector>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
namespace graph3d_visual {
struct P3{double x,y,z;};
#ifdef _WIN32
class Window{
public:
 Window(std::function<double(double,double)> f,double xa,double xb,double ya,double yb,int r,const wchar_t* t):f_(f),xa_(xa),xb_(xb),ya_(ya),yb_(yb),r_(r<8?8:(r>70?70:r)),title_(t?t:L"z=f(x,y)"){build();}
 int run(){self_=this;HINSTANCE h=GetModuleHandleW(nullptr);WNDCLASSW wc{};wc.lpfnWndProc=Proc;wc.hInstance=h;wc.lpszClassName=L"CVPLUS_GRAPH3D";wc.hCursor=LoadCursorW(nullptr,MAKEINTRESOURCEW(32512));wc.hIcon=LoadIconW(nullptr,MAKEINTRESOURCEW(32512));wc.hbrBackground=CreateSolidBrush(RGB(15,23,42));RegisterClassW(&wc);std::wstring cap=title_+L" - Grafico 3D Visuale - Copyright Alessandro Barazzuol";hwnd_=CreateWindowExW(WS_EX_APPWINDOW,wc.lpszClassName,cap.c_str(),WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,1200,780,nullptr,nullptr,h,nullptr);if(!hwnd_)return -1;ShowWindow(hwnd_,SW_MAXIMIZE);MSG m{};while(GetMessageW(&m,nullptr,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}self_=nullptr;return 0;}
private:
 static Window* self_; static LRESULT CALLBACK Proc(HWND h,UINT m,WPARAM w,LPARAM l){return self_?self_->handle(h,m,w,l):DefWindowProcW(h,m,w,l);} 
 LRESULT handle(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_CREATE:create(h);return 0;case WM_SIZE:layout(LOWORD(l),HIWORD(l));InvalidateRect(h,nullptr,TRUE);return 0;case WM_COMMAND:act(LOWORD(w));InvalidateRect(h,nullptr,TRUE);return 0;case WM_KEYDOWN:if(w==VK_LEFT)az_-=.1;else if(w==VK_RIGHT)az_+=.1;else if(w==VK_UP)ax_+=.08;else if(w==VK_DOWN)ax_-=.08;else if(w==VK_ADD||w==L'+')zoom_*=1.12;else if(w==VK_SUBTRACT||w==L'-')zoom_/=1.12;else if(w==VK_ESCAPE){DestroyWindow(h);return 0;}InvalidateRect(h,nullptr,TRUE);return 0;case WM_PAINT:paint(h);return 0;case WM_CLOSE:DestroyWindow(h);return 0;case WM_DESTROY:PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);} 
 void create(HWND h){HINSTANCE i=GetModuleHandleW(nullptr);const wchar_t* tx[]={L"Ruota sx",L"Ruota dx",L"Inclina +",L"Inclina -",L"Zoom +",L"Zoom -",L"Ripristina",L"Chiudi"};int ww[]={100,100,100,100,90,90,110,90};int x=20;for(int k=0;k<8;k++){btn_[k]=CreateWindowW(L"BUTTON",tx[k],WS_CHILD|WS_VISIBLE,x,14,ww[k],34,h,(HMENU)(1001+k),i,nullptr);bw_[k]=ww[k];x+=ww[k]+8;}info_=CreateWindowW(L"STATIC",L"Frecce: rotazione | + e -: zoom | ESC: chiudi",WS_CHILD|WS_VISIBLE,20,56,800,24,h,nullptr,i,nullptr);} 
 void layout(int w,int){int x=20;for(int k=0;k<8;k++){MoveWindow(btn_[k],x,14,bw_[k],34,TRUE);x+=bw_[k]+8;}MoveWindow(info_,20,56,w-40,24,TRUE);} 
 void act(int id){if(id==1001)az_-=.12;else if(id==1002)az_+=.12;else if(id==1003)ax_+=.1;else if(id==1004)ax_-=.1;else if(id==1005)zoom_*=1.15;else if(id==1006)zoom_/=1.15;else if(id==1007){ax_=.72;az_=-.78;zoom_=1;}else if(id==1008)DestroyWindow(hwnd_);} 
 void build(){zmin_=std::numeric_limits<double>::infinity();zmax_=-zmin_;for(int iy=0;iy<=r_;iy++){double y=ya_+(yb_-ya_)*iy/r_;for(int ix=0;ix<=r_;ix++){double x=xa_+(xb_-xa_)*ix/r_;double z=f_(x,y);if(!std::isfinite(z))z=0;pts_.push_back({x,y,z});if(z<zmin_)zmin_=z;if(z>zmax_)zmax_=z;}}if(std::abs(zmax_-zmin_)<1e-12){zmin_-=1;zmax_+=1;}}
 P3 norm(P3 p)const{return {2*(p.x-xa_)/(xb_-xa_)-1,2*(p.y-ya_)/(yb_-ya_)-1,2*(p.z-zmin_)/(zmax_-zmin_)-1};}
 POINT proj(P3 p,RECT a)const{p=norm(p);double cz=cos(az_),sz=sin(az_);double x=p.x*cz-p.y*sz,y=p.x*sz+p.y*cz,z=p.z;double cx=cos(ax_),sx=sin(ax_);double yy=y*cx-z*sx,zz=y*sx+z*cx;double persp=1.0/(2.7-.45*zz);double s=.4*(a.right-a.left)*zoom_*persp;return {(LONG)((a.left+a.right)/2.0+x*s),(LONG)((a.top+a.bottom)/2.0-yy*s)};}
 COLORREF col(double z)const{double t=(z-zmin_)/(zmax_-zmin_);if(t<0)t=0;if(t>1)t=1;return RGB((int)(45+180*t),(int)(120+90*(1-std::abs(2*t-1))),(int)(230-160*t));}
 void line(HDC d,POINT a,POINT b,COLORREF c,int w=1){HPEN p=CreatePen(PS_SOLID,w,c);HGDIOBJ o=SelectObject(d,p);MoveToEx(d,a.x,a.y,nullptr);LineTo(d,b.x,b.y);SelectObject(d,o);DeleteObject(p);} 
 void axis(HDC d,RECT a,P3 p,P3 q,COLORREF c,const wchar_t* s){POINT x=proj(p,a),y=proj(q,a);line(d,x,y,c,3);SetTextColor(d,c);TextOutW(d,y.x+5,y.y-8,s,1);} 
 void paint(HWND h){PAINTSTRUCT ps{};HDC d=BeginPaint(h,&ps);RECT c{};GetClientRect(h,&c);HBRUSH b=CreateSolidBrush(RGB(15,23,42));FillRect(d,&c,b);DeleteObject(b);RECT a{20,90,c.right-20,c.bottom-48};b=CreateSolidBrush(RGB(20,30,48));FillRect(d,&a,b);DeleteObject(b);SetBkMode(d,TRANSPARENT);HFONT ft=CreateFontW(25,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");SelectObject(d,ft);SetTextColor(d,RGB(125,211,252));std::wstring hd=L"Superficie: "+title_;TextOutW(d,24,96,hd.c_str(),(int)hd.size());int s=r_+1;for(int y=0;y<=r_;y++)for(int x=0;x<r_;x++){auto p=pts_[y*s+x],q=pts_[y*s+x+1];line(d,proj(p,a),proj(q,a),col((p.z+q.z)/2));}for(int x=0;x<=r_;x++)for(int y=0;y<r_;y++){auto p=pts_[y*s+x],q=pts_[(y+1)*s+x];line(d,proj(p,a),proj(q,a),col((p.z+q.z)/2));}double z0=(0<zmin_||0>zmax_)?zmin_:0;axis(d,a,{xa_,0,z0},{xb_,0,z0},RGB(248,113,113),L"X");axis(d,a,{0,ya_,z0},{0,yb_,z0},RGB(74,222,128),L"Y");axis(d,a,{0,0,zmin_},{0,0,zmax_},RGB(96,165,250),L"Z");DeleteObject(ft);EndPaint(h,&ps);} 
 std::function<double(double,double)> f_;double xa_,xb_,ya_,yb_;int r_;std::wstring title_;std::vector<P3> pts_;double zmin_,zmax_,ax_=.72,az_=-.78,zoom_=1;HWND hwnd_=nullptr,info_=nullptr,btn_[8]{};int bw_[8]{};
};
Window* Window::self_=nullptr;
template<class F> inline int visualizzaFunzione3D(F f,double xmin=-5,double xmax=5,double ymin=-5,double ymax=5,int risoluzione=35,const wchar_t* titolo=L"z=f(x,y)"){Window w(std::function<double(double,double)>(f),xmin,xmax,ymin,ymax,risoluzione,titolo);return w.run();}
#else
template<class F> inline int visualizzaFunzione3D(F,double=-5,double=5,double=-5,double=5,int=35,const wchar_t*=L"z=f(x,y)"){return 0;}
#endif
}
using graph3d_visual::visualizzaFunzione3D;
#endif
