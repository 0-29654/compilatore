#include <cmath>
#include <graph3d_visual.h>
int main(){ visualizzaFunzione3D([](double x,double y){return std::sin(x)*std::cos(y);},-6.28,6.28,-6.28,6.28,45,L"z = sin(x) cos(y)"); return 0;}
