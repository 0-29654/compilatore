#include <graph3d_visual.h>
int main(){ visualizzaFunzione3D([](double x,double y){return x*x-y*y;},-4,4,-4,4,38,L"z = x^2 - y^2"); return 0;}
