#include <cmath>
#include <graph3d_visual.h>
int main(){ visualizzaFunzione3D([](double x,double y){return std::exp(-(x*x+y*y));},-3,3,-3,3,45,L"z = exp(-(x^2+y^2))"); return 0;}
